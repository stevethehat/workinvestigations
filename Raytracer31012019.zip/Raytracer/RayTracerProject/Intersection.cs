﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Intersection
    {
        public Intersection(double time, Shape shape)
        {
            Time = time;
            Shape = shape;
        }

        public double Time { get; }
        public Shape Shape { get; }
  
        public Point Point { get; private set; }
        public Vector Eye { get; private set; }
        public Vector Normal { get; private set; }
        public Vector Reflected { get; private set; }

        public bool Inside { get; private set; }

        public void PerpareHit(Ray ray)
        {
            Point = ray.Position(Time);
            Eye = (-ray.Direction).AsVector();
            Normal = Shape.NormalAt(Point);
            Reflected = (-ray.Direction).Reflect(Normal).AsVector();


    

            if (Normal.Dot(Eye) < 0)
            {
                Inside = true;
                Normal = (-Normal).AsVector();
            } 
            else
            {
                Inside = false;
            }
            //hit.point ← hit.point + hit.normalv * 0.0001
            Point = (Point + Normal * 0.0001d).AsPoint();
        }

        public void PrepareComputations(Ray ray)
        {
            PerpareHit(ray);
        }

        public override string ToString()
        {
            return $"Time: {Time}";
        }
    }
}
