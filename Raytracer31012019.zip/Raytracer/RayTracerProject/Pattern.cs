﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Pattern
    {
        public Matrix Transform { get; set; } = Matrix.Identity();
        public virtual RColor ColorAt(Point point)
        {
            return new RColor();
        }

        public virtual RColor ColorAt(Shape shape, Point point)
        {
            RTuple objectPoint = shape.Transform.Invert() * point;
            RTuple patternPoint = Transform.Invert() * objectPoint;
            return ColorAt(patternPoint.AsPoint());
        }
    }
}
