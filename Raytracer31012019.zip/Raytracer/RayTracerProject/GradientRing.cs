﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class GradientRing : Pattern
    {
        public RColor ColorA { get; private set; }
        public RColor ColorB { get; private set; }

        public GradientRing(RColor colorA, RColor colorB)
        {
            ColorA = colorA;
            ColorB = colorB;
        }

        public override RColor ColorAt(Point point)
        {
            Point origin = new Point(0, 0, 0);
            RTuple distance = (point - origin);
            double test = (point.X * point.X) + (point.Z * point.Z);

            return ColorA + (ColorB - ColorA) * (point.X - Math.Floor(Math.Sqrt(test)));
            if (Math.Floor(Math.Sqrt(test)) % 2 == 0)
            {
                return ColorA;
                //return ColorA + (ColorB - ColorA) * (point.X - Math.Floor(point.X));
                //return ColorA + ((ColorB - ColorA) *  Math.Floor(Math.Sqrt((point.X * point.X) + (point.Z * point.Z))));
            }
            else
            {
                return ColorB;
            }
        }


    }
}
