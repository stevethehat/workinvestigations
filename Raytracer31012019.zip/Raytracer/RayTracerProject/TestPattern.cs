﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class TestPattern : Pattern
    {
        public override RColor ColorAt(Point point)
        {
            return new RColor(point.X, point.Y, point.Z);
        }
    }

}
