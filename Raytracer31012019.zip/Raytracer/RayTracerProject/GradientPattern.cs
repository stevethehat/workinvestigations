﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class GradientPattern: Pattern
    {
        public RColor ColorA { get; private set; }
        public RColor ColorB { get; private set; }

        public GradientPattern(RColor colorA, RColor colorB)
        {
            ColorA = colorA;
            ColorB = colorB;
        }

        public override RColor ColorAt(Point point)
        {
            RColor result = ColorA + (ColorB - ColorA) * (point.X - Math.Floor(point.X));
            return result;
        }

    }
}
