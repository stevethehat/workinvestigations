﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class BlendedPattern: Pattern
    {
        public Pattern PatternA;
        public Pattern PatternB;
        public BlendedPattern(Pattern patternA, Pattern patternB)
        {
            PatternA = patternA;
            PatternB = patternB;
        }
        public override RColor ColorAt(Shape shape, Point point)
        {
            RColor colorA = PatternA.ColorAt(shape, point);
            RColor colorB = PatternB.ColorAt(shape, point);

            return new RColor(
                (colorA.R + colorB.R) / 2,
                (colorA.G + colorB.G) / 2,
                (colorA.B + colorB.B) / 2);
        }
    }
}
