﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class RingPattern: Pattern
    {
        public RColor ColorA { get; private set; }
        public RColor ColorB { get; private set; }

        public RingPattern(RColor colorA, RColor colorB)
        {
            ColorA = colorA;
            ColorB = colorB;
        }

        public override RColor ColorAt(Point point)
        {
            double test = (point.X * point.X) + (point.Z * point.Z);
            if(Math.Floor(Math.Sqrt(test)) % 2 == 0)
            {
                return ColorA;
            }
            else
            {
                return ColorB;
            }
        }

    }
}
