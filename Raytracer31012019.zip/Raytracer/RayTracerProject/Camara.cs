﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Camera
    {
        private Point _defaultPoint;

        public double HSize { get; set; }
        public double VSize { get; set; }
        public double FieldOfView { get; set; }
        public double PixelSize { get; private set; }
        public double HalfWidth { get; private set; }
        public double HalfHeight { get; private set; }

        private Matrix _Transform;
        public Matrix Transform {
            get => _Transform;
            set
            {
                _Transform = value;
                InvertedTransform = _Transform.Invert();
            }
        }
        public Matrix InvertedTransform { get; private set; }

        public Camera(double hSize, double vSize, double fieldOfView)
        {
            HSize = hSize;
            VSize = vSize;
            FieldOfView = fieldOfView;
            Transform = Matrix.Identity();

            double halfView = Math.Tan(FieldOfView / 2);
            double aspect = HSize / VSize;

            if(aspect >= 1)
            {
                HalfWidth = halfView;
                HalfHeight = halfView / aspect;
            } else
            {
                HalfWidth = halfView * aspect;
                HalfHeight = halfView;
            }
            PixelSize = (HalfWidth * 2) / HSize;

            _defaultPoint = new Point(0, 0, 0);
        }

        public Ray RayForPixel(double px, double py)
        {
            var xOffset = (px + 0.5) * PixelSize;
            var yOffset = (py + 0.5) * PixelSize;

            var worldX = HalfWidth - xOffset;
            var worldY = HalfHeight - yOffset;

            var pixel = InvertedTransform * new Point(worldX, worldY, -1);
            var origin = InvertedTransform * _defaultPoint;

            var direction = (pixel - origin).Normalize();

            return new Ray(origin.AsPoint(), direction.AsVector());

        }

        public Canvas Render(World world)
        {
            int HSizeInt = Convert.ToInt32(HSize);
            int VSizeInt = Convert.ToInt32(VSize);
            var image = new Canvas(HSizeInt, VSizeInt);

            for (int y = 0; y < VSizeInt; y++)
            {
                for (int x = 0; x < HSizeInt; x++)
                {
                    var ray = RayForPixel(x, y);
                    var colour = world.ColorAt(ray);
                    image[x, y] = colour;
                }
            }


            return image;
        }

        public Canvas ParallelRender(World world)
        {
            int HSizeInt = Convert.ToInt32(HSize);
            int VSizeInt = Convert.ToInt32(VSize);
            var image = new Canvas(HSizeInt, VSizeInt);

            var yRange = Enumerable.Range(0, VSizeInt);
            Parallel.ForEach(yRange, y => {
                for (int x = 0; x < HSizeInt; x++)
                {
                    var ray = RayForPixel(x, y);
                    var colour = world.ColorAt(ray);
                    image[x, y] = colour;
                }
            });

            return image;
        }


    }
}
