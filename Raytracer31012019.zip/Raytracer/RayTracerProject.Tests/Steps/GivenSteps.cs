﻿using System;
using TechTalk.SpecFlow;
using System.Linq;
using System.Text.RegularExpressions;

namespace RayTracerProject.Tests
{
    [Binding]
    public class GivenSteps
    {
        [Given(@"(\w*) ← ray\(point\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\), vector\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)\)")]
        public void GivenRRayPointVector(string rayName, double px, double py, double pz, double vx, double vy, double vz)
        {
            ScenarioContext.Current[rayName] = new Ray(new Point(px, py, pz), new Vector(vx, vy, vz));
        }

        [Given(@"(\w*) ← ray\(point\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\), vector\((-?\d*\.?\d*), -√(\d*)\/(\d*), √(\d*)\/(\d*)\)\)")]
        public void GivenRRayPointVector2(string rayName, double px, double py, double pz, double vx, double vy1, double vy2, double vz1, double vz2)
        {
            ScenarioContext.Current[rayName] = new Ray(new Point(px, py, pz), new Vector(vx, -Math.Sqrt(vy1) / vy2, Math.Sqrt(vz1) / vz2));
        }

        [Given(@"(\w*) ← sphere\(\)")]
        public void GivenSSphere(string sphereName)
        {
            ScenarioContext.Current[sphereName] = new Sphere();
        }

        [Given(@"(\w*) ← intersection\((-?\d*\.?\d*), (\w*)\)")]
        public void WhenIIntersectionS(string intersectionName, double time, string shapeName)
        {
            var sphere = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[intersectionName] = new Intersection(time, sphere);
        }

        [Given(@"(\w*) ← intersection\(√(-?\d*\.?\d*), (\w*)\)")]
        public void WhenIIntersectionSqrt(string intersectionName, double time, string shapeName)
        {
            var sphere = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[intersectionName] = new Intersection(Math.Sqrt(time), sphere);
        }

        [Given(@"(\w*) ← intersections\((\w*), (\w*)\)")]
        public void WhenXsIntersectionsII(string intersectionsName, string intersection1Name, string intersection2Name)
        {
            Intersection intersection1 = (Intersection)ScenarioContext.Current[intersection1Name];
            Intersection intersection2 = (Intersection)ScenarioContext.Current[intersection2Name];

            Intersections intersections = new Intersections();
            intersections.Add(intersection1);
            intersections.Add(intersection2);

            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [Given(@"(\w*) ← intersections\((\w*), (\w*), (\w*), (\w*)\)")]
        public void WhenXsIntersections4(string intersectionsName, string intersection1Name, string intersection2Name, string intersection3Name, string intersection4Name)
        {
            Intersection intersection1 = (Intersection)ScenarioContext.Current[intersection1Name];
            Intersection intersection2 = (Intersection)ScenarioContext.Current[intersection2Name];
            Intersection intersection3 = (Intersection)ScenarioContext.Current[intersection3Name];
            Intersection intersection4 = (Intersection)ScenarioContext.Current[intersection4Name];

            Intersections intersections = new Intersections();
            intersections.Add(intersection1);
            intersections.Add(intersection2);
            intersections.Add(intersection3);
            intersections.Add(intersection4);

            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [Given(@"set_transform\((\w*), translation\((.*), (.*), (.*)\)\)")]
        public void GivenSet_TransformSTranslation(string sphereName, double x, double y, double z)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            sphere.Transform = Matrix.Translation(x, y, z);
        }

        [Given(@"set_transform\((\w*), scaling\((.*), (.*), (.*)\)\)")]
        public void GivenSet_TransformSScaling(string sphereName, double x, double y, double z)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            sphere.Transform = Matrix.Scale(x, y, z);
        }

        [Given(@"set_transform\((\w*), rotY\(π/(.*)\)")]
        public void GivenSet_TransformSRotYΠ(string sphereName, double degrees)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            sphere.Transform = Matrix.RotateY(Math.PI / degrees);
        }

        [Given(@"(.*) ← vector\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)")]
        public void GivenVVector(string name, double x, double y, double z)
        {
            ScenarioContext.Current[name] = new Vector(x, y, z);
        }

        [Given(@"(.*) ← vector\(√(-?\d*\.?\d*)\/(-?\d*\.?\d*), √(-?\d*\.?\d*)\/(-?\d*\.?\d*), (-?\d*\.?\d*)\)")]
        public void GivenVVector2(string name, double x1, double x2, double y1, double y2, double z)
        {
            ScenarioContext.Current[name] = new Vector(Math.Sqrt(x1) / x2, Math.Sqrt(y1)/ y2, z);
        }

        [Given(@"(\w*) ← vector\((.*), -√(-?\d*\.?\d*)\/(-?\d*\.?\d*), -√(-?\d*\.?\d*)\/(-?\d*\.?\d*)\)")]
        public void GivenEyevVector__(string vectorName, double x, double y1, double y2, double z1, double z2)
        {
            ScenarioContext.Current[vectorName] = new Vector(x, -Math.Sqrt(y1) / y2, -Math.Sqrt(z1) / z2);
        }

        [Given(@"(\w*) ← vector\((.*), √(-?\d*\.?\d*)\/(-?\d*\.?\d*), -√(-?\d*\.?\d*)\/(-?\d*\.?\d*)\)")]
        public void GivenEyevVector___(string vectorName, double x, double y1, double y2, double z1, double z2)
        {
            ScenarioContext.Current[vectorName] = new Vector(x, Math.Sqrt(y1) / y2, -Math.Sqrt(z1) / z2);
        }

        [Given(@"(\w*) ← material\(\)")]
        public void GivenMMaterial(string materialName)
        {
            ScenarioContext.Current[materialName] = new Material();
        }

        [Given(@"(\w*)\.ambient ← (.*)")]
        public void GivenM_Ambient(string materialName, double ambient)
        {
            var material = (Material)ScenarioContext.Current[materialName];
            material.Ambient = ambient;
        }

        [Given(@"(\w*) ← point_light\(point\((.*), (.*), (.*)\), color\((.*), (.*), (.*)\)\)")]
        public void GivenLightPoint_LightPointColor(string lightName, double x, double y, double z, double r, double g, double b)
        {
            ScenarioContext.Current[lightName] = new PointLight(new Point(x, y, z), new RColor(r, g, b));
        }

        [Given(@"(\w*) ← world\(\)")]
        public void GivenWWorld(string worldName)
        {
            ScenarioContext.Current[worldName] = new World();
        }

        protected void AddProperty(Shape shape, string[] row)
        {
            Regex regex;
            Match matches;
            switch (row[0])
            {
                case "color":
                    //sphere.Material.Color
                    regex = new Regex(@"(\d.\d), (\d.\d). (\d.\d)");

                    matches = regex.Match(row[1]);
                    shape.Material.Color = new RColor(Convert.ToDouble(matches.Groups[1].Value), Convert.ToDouble(matches.Groups[2].Value), Convert.ToDouble(matches.Groups[3].Value));                    
                    break;
                case "diffuse":
                    shape.Material.Diffuse = Convert.ToDouble(row[1]);
                    break;
                case "specular":
                    shape.Material.Specular = Convert.ToDouble(row[1]);
                    break;
                case "reflective":
                    shape.Material.Reflective = Convert.ToDouble(row[1]);
                    break;
                case "transform":
                    if (row[1].StartsWith("scaling"))
                    {
                        regex = new Regex(@"scaling\((\d.\d), (\d.\d). (\d.\d)\)");
                        matches = regex.Match(row[1]);
                        if (matches.Success)
                        {
                            shape.Transform = Matrix.Scale(Convert.ToDouble(matches.Groups[1].Value), Convert.ToDouble(matches.Groups[2].Value), Convert.ToDouble(matches.Groups[3].Value));
                        }
                    }
                    else if (row[1].StartsWith("translation"))
                    {
                        regex = new Regex(@"translation\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)");
                        matches = regex.Match(row[1]);
                        if (matches.Success)
                        {
                            shape.Transform = Matrix.Translation(Convert.ToDouble(matches.Groups[1].Value), Convert.ToDouble(matches.Groups[2].Value), Convert.ToDouble(matches.Groups[3].Value));
                        }
                    }
                    //sphere.Transform
                    break;
            }
        }

        [Given(@"(\w*) ← sphere\(\) with:")]
        public void GivenSSphereWith(string sphereName, Table table)
        {
            Sphere sphere = new Sphere();
            AddProperty(sphere, table.Header.ToArray());

            for (int x = 0; x < table.RowCount; x++)
            {
                TableRow row = table.Rows[x];
                for (int y = 0; y < row.Count; y++)
                {
                    AddProperty(sphere, row.Values.Select(r => r.ToString()).ToArray());
                }
            }

            ScenarioContext.Current[sphereName] = sphere;
        }


        [Given(@"(\w*) ← default_world\(\)")]
        public void DefaultWWorld(string worldName)
        {
            ScenarioContext.Current[worldName] = World.Default();
        }


        [Given(@"(\w*) ← the first object in (\w*)")]
        public void GivenShapeTheFirstObjectInWorld(string objectName, string worldName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            ScenarioContext.Current[objectName] = world.Objects[0];
        }

        [Given(@"(\w*) ← the second object in (\w*)")]
        public void GivenShapeTheSecondObjectInWorld(string objectName, string worldName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            ScenarioContext.Current[objectName] = world.Objects[1];
        }

        [Given(@"(\w*)\.light ← point_light\(point\((.*), (.*), (.*)\), color\((.*), (.*), (.*)\)\)")]
        public void GivenWorld_LightPoint_LightPointColor(string worldName, double x, double y, double z, double r, double g, double b)
        {
            World world = (World)ScenarioContext.Current[worldName];
            if(world.Lights.Count == 0)
            {
                world.Lights.Add(new PointLight(new Point(x, y, z), new RColor(r, g, b)));

            }
            else
            {
                world.Lights[0] = new PointLight(new Point(x, y, z), new RColor(r, g, b));

            }

        }

        [Given(@"(\w*)\.material\.ambient ← (\d*)")]
        public void GivenOuter_Material_Ambient(string objectName, double ambient)
        {
            Sphere sphere = (Sphere)ScenarioContext.Current[objectName];
            sphere.Material.Ambient = ambient;
        }

        [Given(@"(\w*) ← (\d*)")]
        public void GivenHsize(string varName, double value)
        {
            ScenarioContext.Current[varName] = value;
        }


        [Given(@"(\w*) ← π/(.*)")]
        public void GivenField_Of_ViewΠ(string varName, double value)
        {
            ScenarioContext.Current[varName] = Math.PI / value;

        }

        [Given(@"(\w*) ← camera\((\d*), (\d*), π/(\d*)\)")]
        public void WhenCCameraHsizeVsizeField_Of_View(string cameraName, double hValue, double vValue, double fieldOfView)
        {

            ScenarioContext.Current[cameraName] = new Camera(hValue, vValue, Math.PI /fieldOfView);
        }

        [Given(@"(\w*)\.transform ← view_transform\((\w*), (\w*), (\w*)\)")]
        public void GivenC_TransformView_TransformFromToUp(string cameraName, string fromName, string toName, string upName)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            Point from = (Point)ScenarioContext.Current[fromName];
            Point to = (Point)ScenarioContext.Current[toName];
            Vector up = (Vector)ScenarioContext.Current[upName];
            camera.Transform = Matrix.ViewTransform(from, to, up);
        }

        [Given(@"(\w*)\.diffuse ← (.*)")]
        public void GivenM_Diffuse(string materialName, double defuse)
        {
            Material material = (Material)ScenarioContext.Current[materialName];
            material.Diffuse = defuse;
        }

        [Given(@"(\w*)\.specular ← (.*)")]
        public void GivenM_Specular(string materialName, double specular)
        {
            Material material = (Material)ScenarioContext.Current[materialName];
            material.Specular = specular;
        }

        [Given(@"in_shadow ← (\w*)")]
        public void GivenIn_ShadowTrue(string boolVal)
        {
            ScenarioContext.Current["in_shadow"] = Convert.ToBoolean(boolVal);
        }


        [Given(@"(\w*) is added to (\w*)")]
        public void GivenSIsAddedToW(string shapeName, string worldName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Shape shape = (Shape)ScenarioContext.Current[shapeName];

            world.Objects.Add(shape);
        }


        /***** Shapes ******/
        [Given(@"(\w*) ← test_shape\(\)")]
        public void GivenSTest_Shape(string shapeName)
        {
            Shape testShape = new TestShape();

            ScenarioContext.Current[shapeName] = testShape;

            
        }

        /***** Plains ******/

        [Given(@"(\w*) ← plane\(\)")]
        public void GivenPPlane(string plainName)
        {
            ScenarioContext.Current[plainName] = new Plane();
        }


        /***** Patterns ****/


        [Given(@"(\w*) ← stripe_pattern\(white, black\)")]
        public void GivenPatternStripe_PatternWhiteBlack(string patternName)
        {
            RColor black = new RColor(0, 0, 0);
            RColor white = new RColor(1, 1, 1);

            StripePattern pattern = new StripePattern(white, black);

            ScenarioContext.Current[patternName] = pattern;
        }

        private RColor GetColor(string colorName)
        {
            switch (colorName.ToLower())
            {
                case "white":
                    return new RColor(1, 1, 1);
                default:
                    return new RColor(0, 0, 0);
            }
        }

        [Given(@"(\w*)\.pattern ← stripe_pattern\((\w*), (\w*)\)")]
        public void GivenM_PatternStripe_PatternWhiteBlack(string materialName, string a, string b)
        {
            RColor colorA = GetColor(a);
            RColor colorB = GetColor(b);

            Material material = (Material)ScenarioContext.Current[materialName];
            Pattern pattern = new StripePattern(colorA, colorB);
            material.Pattern = pattern;
        }


        [Given(@"set_pattern_transform\((\w*), scaling\((.*), (.*), (.*)\)\)")]
        public void GivenSet_Pattern_TransformPatternScaling(string patternName, double x, double y, double z)
        {
            Pattern pattern = (Pattern)ScenarioContext.Current[patternName];
            pattern.Transform = Matrix.Scale(x, y, z);
        }

        [Given(@"set_pattern_transform\((\w*), translation\((.*), (.*), (.*)\)\)")]
        public void GivenSet_Pattern_TransformPatternTranslation(string patternName, double x, double y, double z)
        {
            Pattern pattern = (Pattern)ScenarioContext.Current[patternName];
            pattern.Transform = Matrix.Translation(x, y, z);
        }

        [Given(@"(\w*) ← test_pattern\(\)")]
        public void GivenPatternTest_Pattern(string patternName)
        {
            ScenarioContext.Current[patternName] = new TestPattern();
        }


        [Given(@"(\w*) ← gradient_pattern\(black, white\)")]
        public void GivenPatternGradient_PatternBlackWhite(string patternName)
        {
            RColor black = new RColor(0, 0, 0);
            RColor white = new RColor(1, 1, 1);
            var gradient = new GradientPattern(black, white);

            ScenarioContext.Current[patternName] = gradient;
        }

        [Given(@"(\w*) ← ring_pattern\(black, white\)")]
        public void GivenPatternRing_PatternBlackWhite(string patternName)
        {
            RColor black = new RColor(0, 0, 0);
            RColor white = new RColor(1, 1, 1);
            var ring = new RingPattern(black, white);

            ScenarioContext.Current[patternName] = ring;
        }

        [Given(@"(\w*) ← checkers_pattern\(black, white\)")]
        public void GivenPatternCheckers_PatternBlackWhite(string patternName)
        {
            RColor black = new RColor(0, 0, 0);
            RColor white = new RColor(1, 1, 1);
            var checkers = new CheckersPattern(black, white);

            ScenarioContext.Current[patternName] = checkers;
        }

        [Given(@"(\w*) ← stripe_pattern\(black, white\)")]
        public void GivenPatternStripe_PatternBlackWhite(string patternName)
        {
            RColor black = new RColor(0, 0, 0);
            RColor white = new RColor(1, 1, 1);
            Pattern pattern = new StripePattern(black, white);
            ScenarioContext.Current[patternName] = pattern;
        }


        [Given(@"(\w*) ← plane\(\) with:")]
        public void GivenShapePlaneWith(string shapeName, Table table)
        {
            Plane plane = new Plane();
            AddProperty(plane, table.Header.ToArray());

            for (int x = 0; x < table.RowCount; x++)
            {
                TableRow row = table.Rows[x];
                for (int y = 0; y < row.Count; y++)
                {
                    AddProperty(plane, row.Values.Select(r => r.ToString()).ToArray());
                }
            }

            ScenarioContext.Current[shapeName] = plane;
        }

        /***** Reflection ****/


        [Given(@"(\w*) ← glass_sphere\(\)")]
        public void GivenSGlass_Sphere(string sphereName)
        {
            Sphere glass = new Sphere();
            glass.Material.Transparency = 1;
            glass.Material.RefractiveIndex = 1.5;
            ScenarioContext.Current[sphereName] = glass;
        }

        [Given(@"(\w*) ← glass_sphere\(\) with:")]
        public void GivenAGlass_SphereWith(string sphereName, Table table)
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"(\w*) ← intersections\((.*):A, (.*):B, (.*):C, (.*):B, (.*):C, (.*):A\)")]
        public void GivenXsIntersectionsABCBCA(string intersectionsName, double p0, double p1, double p2, double p3, double p4, double p5)
        {
            //TODO: I'm not 100% sure how to handle this one
            ScenarioContext.Current.Pending();
        }

        [Given(@"xs ← intersections\(hit\)")]
        public void GivenXsIntersectionsHit(string intersectionsName, string hitName)
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"xs ← intersections\((.*):shape, (.*):shape\)")]
        public void GivenXsIntersectionsShapeShape(string interestionsName, double p0, double p1)
        {
            //TODO: I'm not 100% sure how to handle this one
            ScenarioContext.Current.Pending();
        }

        [Given(@"(\w*) has:")]
        public void GivenShapeHas(string shapeName, Table table)
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"(\w*) ← intersections\((.*):A, (.*):B, (.*):B, (.*):A\)")]
        public void GivenXsIntersectionsABBA(string intersectionsName, double p0, double p1, double p2, double p3)
        {
            //TODO: I'm not 100% sure how to handle this one
            ScenarioContext.Current.Pending();
        }

        [Given(@"(\w*) ← intersections\(√(.*):floor\)")]
        public void GivenXsIntersectionsFloor(string intersectionsName, double p0)
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"(\w*) ← intersections\((.*):shape\)")]
        public void GivenXsIntersectionsShape(double p0)
        {
            ScenarioContext.Current.Pending();
        }




    }
}
