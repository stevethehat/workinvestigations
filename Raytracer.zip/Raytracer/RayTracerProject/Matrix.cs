﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Matrix
    {
        public int Rows { get; }
        public int Cols { get; }

        public bool IsInvertable
        {
            get => Determinant() != 0;
        }

        private double[,] cells;

        public double this[int row, int column]
        {
            get => cells[row, column];
            set => cells[row, column] = value;
        }

        public Matrix(int rows, int cols)
        {
            this.Rows = rows;
            this.Cols = cols;
            Init();
        }

        private void Init()
        {
            cells = new double[Rows, Cols];
        }



        public static Matrix Translation(double x, double y, double z)
        {
            Matrix result = Identity();
            result[0, 3] = x;
            result[1, 3] = y;
            result[2, 3] = z;
            return result;
        }

        public static Matrix Scale(double x, double y, double z)
        {
            Matrix result = Identity();
            result[0, 0] = x;
            result[1, 1] = y;
            result[2, 2] = z;
            return result;
        }

        public static Matrix RotateX(double degree)
        {
            Matrix result = Identity();
            result[1, 1] = Math.Cos(degree);
            result[1, 2] = -Math.Sin(degree);
            result[2, 1] = Math.Sin(degree);
            result[2, 2] = Math.Cos(degree);
            return result;
        }

        public static Matrix RotateY(double degree)
        {
            Matrix result = Identity();
            result[0, 0] = Math.Cos(degree);
            result[0, 2] = Math.Sin(degree);
            result[2, 0] = -Math.Sin(degree);
            result[2, 2] = Math.Cos(degree);
            return result;
        }

        public static Matrix RotateZ(double degree)
        {
            Matrix result = Identity();
            result[0, 0] = Math.Cos(degree);
            result[0, 1] = -Math.Sin(degree);
            result[1, 0] = Math.Sin(degree);
            result[1, 1] = Math.Cos(degree);
            return result;
        }

        public static Matrix Shear(double xY, double xZ, double yX, double yZ, double zX, double zY)
        {
            Matrix result = Identity();
            result[0, 1] = xY;
            result[0, 2] = xZ;
            result[1, 0] = yX;
            result[1, 2] = yZ;
            result[2, 0] = zX;
            result[2, 1] = zY;
            return result;
        }

        public static RTuple operator *(Matrix left, RTuple right)
        {
            double[] rightArray = right.ToArray();
            double[] resultArray = new double[4];

            for (int row = 0; row < left.Rows; row++)
            {
                double result = 0;
                left.Row(row, (col, value) =>
                {
                    double byValue = rightArray[col];
                    result += value * byValue;

                    return value;
                });
                resultArray[row] = result;
            }

            return RTuple.FromArray(resultArray);
        }

        public static RTuple operator *(RTuple right, Matrix left)
        {
            double[] rightArray = right.ToArray();
            double[] resultArray = new double[4];

            for (int row = 0; row < left.Rows; row++)
            {
                double result = 0;
                left.Row(row, (col, value) =>
                {
                    double byValue = rightArray[col];
                    result += value * byValue;

                    return value;
                });
                resultArray[row] = result;
            }

            return RTuple.FromArray(resultArray);
        }

        public static Matrix operator *(Matrix left, Matrix right)
        {

            return left.All((row, col, _) =>
            {
                double result = 0;

                left.Row(row, (rowCol, value) =>
                {
                    double byValue = right[rowCol, col];
                    result += value * byValue;
                    return value;
                });

                return result;
            });
        }

        public static Matrix Identity()
        {
            Matrix result = new Matrix(4, 4);
            result[0, 0] = 1;
            result[1, 1] = 1;
            result[2, 2] = 1;
            result[3, 3] = 1;
            return result;
        }

        public static Matrix ViewTransform(Point from, Point to, Vector up)
        {
            var forward = (to - from).Normalize();
            var upn = up.Normalize();
            var left = forward.Cross(upn);

            var trueUp = left.Cross(forward);

            var orientation = Identity();

            orientation[0, 0] = left.X;
            orientation[0, 1] = left.Y;
            orientation[0, 2] = left.Z;
            orientation[1, 0] = trueUp.X;
            orientation[1, 1] = trueUp.Y;
            orientation[1, 2] = trueUp.Z;
            orientation[2, 0] = -forward.X;
            orientation[2, 1] = -forward.Y;
            orientation[2, 2] = -forward.Z;


            var result =  orientation * Translation(-from.X, -from.Y, -from.Z);
            return result;
        }

        public Matrix Transpose()
        {
            return All((row, col, value) =>
            {
                return this[col, row];
            });
        }

        public double Determinant()
        {
            if (Rows == 2 && Cols == 2)
            {
                return (this[0, 0] * this[1, 1]) - (this[0, 1] * this[1, 0]);
            }
            else
            {
                double result = 0;
                Row(0, (col, value) =>
                {
                    double cofactor = Cofactor(0, col);
                    result += (value * cofactor);
                    return value;
                });
                return result;
            }
        }

        public Matrix SubMatrix(int removeRow, int removeCol)
        {
            Matrix result = new Matrix(Rows - 1, Cols - 1);

            int insertRow = 0;
            for (int row = 0; row < Rows; row++)
            {
                if (row != removeRow)
                {
                    int insertCol = 0;
                    for (int col = 0; col < Cols; col++)
                    {
                        if (col != removeCol)
                        {
                            result[insertRow, insertCol] = this[row, col];
                            insertCol++;
                        }
                    }
                    insertRow++;
                }
            }

            return result;
        }

        public double Minor(int row, int col)
        {
            double result = 0;
            Matrix subMatrix = this.SubMatrix(row, col);

            return subMatrix.Determinant();

        }
        public double Cofactor(int row, int col)
        {
            double result = Minor(row, col);
            if ((row + col) % 2 == 1)
            {
                result = result * -1;
            }
            return result;
        }

        public Matrix Invert()
        {
            Matrix cofactors = All((int row, int col, double value) => {
                return Cofactor(row, col);
            });

            Matrix transposed = cofactors.Transpose();

            double determinant = Determinant();

            Matrix result = transposed.All((int row, int col, double value) => {
                return value / determinant;
            });

            return result;
        }

        protected Matrix All(Func<int, int, double, double> cellFunction)
        {
            Matrix result = new Matrix(Rows, Cols);

            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Cols; col++)
                {
                    result[row, col] = cellFunction(row, col, this[row, col]);
                }
            }

            return result;
        }

        protected void Row(int row, Func<int, double, double> cellFunction)
        {
            for (int col = 0; col < Cols; col++)
            {
                cellFunction(col, this[row, col]);
            }
        }
        protected void Col(int col, Func<int, double, double> cellFunction)
        {
            for (int row = 0; row < Rows; row++)
            {
                cellFunction(row, this[row, col]);
            }
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("[");
            for (int row = 0; row < Rows; row++)
            {
                for (int column = 0; column < Cols; column++)
                {
                    sb.Append($"{cells[row, column]} ");
                }
                sb.AppendLine();
            }
            sb.Append("]");

            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            const double EPSILON = 0.00001;
            if (obj is Matrix matrix)
            {
                bool result = true;
                this.All((x, y, value) =>
                {

                    var rightVal = matrix[x, y];
                    if ((rightVal - value) > EPSILON)
                    {
                        result = false;
                    }
                    return value;
                });

                return result;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return -21579390 + EqualityComparer<double[,]>.Default.GetHashCode(cells);
        }
    }
}
