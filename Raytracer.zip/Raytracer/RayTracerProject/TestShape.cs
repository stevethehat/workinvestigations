﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class TestShape : Shape
    {
       public Ray SavedRay { get; private set; }

        public override RTuple LocalNormalAt(RTuple point)
        {
            return point;
        }

        public override Intersections LocalIntersect(Ray ray)
        {
            SavedRay = ray;
            return new Intersections();
        }
    }
}
