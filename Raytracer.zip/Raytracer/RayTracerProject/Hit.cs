﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Hit
    {
        public Point Point { get; set; }
        public Vector Eye { get; set; }

        public Vector Normal { get; set; }

    }
}
