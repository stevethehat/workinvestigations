﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Hit : Intersection
    {
        public Hit(double time, Shape shape) : base(time, shape)
        {

        }

    }
}
