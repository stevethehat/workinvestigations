﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Sphere: Shape
    {

        protected Point origin;
        public Sphere()
        {
            origin = new Point(0, 0, 0);
            Transform = Matrix.Identity();
        }

        //public override Vector NormalAt(Point worldPoint)
        //{
        //    var objectPoint = Transform.Invert() * worldPoint;
        //    var objectNormal = objectPoint - new Point(0, 0, 0);
        //    var worldNormal = (Transform.Invert().Transpose() * objectNormal);

        //    worldNormal.W = 0; // Needs to turn it to a vector before normalizing

        //    return worldNormal.Normalize().AsVector();
        //}

        public override RTuple LocalNormalAt(RTuple point)
        {
            return point - new Point(0, 0, 0);
        }


        public override Intersections LocalIntersect(Ray ray)
        {
            Intersections intersections = new Intersections();

            var sphereToRay = ray.Origin - new Point(0, 0, 0);
            var a = ray.Direction.Dot(ray.Direction);
            var b = 2 * ray.Direction.Dot(sphereToRay);
            var c = sphereToRay.Dot(sphereToRay) - 1;

            var discriminant = b * b - 4 * a * c;

            if (discriminant > -1)
            {
                var t1 = (-b - Math.Sqrt(discriminant)) / (2 * a);
                var t2 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                var time1 = new Intersection(t1, this);
                var time2 = new Intersection(t2, this);


                if (t1 > t2)
                {
                    intersections.Add(time2);
                    intersections.Add(time1);
                }
                else
                {
                    intersections.Add(time1);
                    intersections.Add(time2);
                }
            }


            return intersections;
        }
    }

}
