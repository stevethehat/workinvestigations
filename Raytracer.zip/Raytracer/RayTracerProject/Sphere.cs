﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Sphere
    {
        public Matrix Transform { get; set; }
        public Material Material { get; set; }

        protected Point origin;
        public Sphere()
        {
            origin = new Point(0, 0, 0);
            Transform = Matrix.Identity();
            Material = new Material();
        }

        public Vector NormalAt(Point worldPoint)
        {
            var objectPoint = Transform.Invert() * worldPoint;
            var objectNormal = objectPoint - new Point(0, 0, 0);
            var worldNormal = (Transform.Invert().Transpose() * objectNormal);

            worldNormal.W = 0; // Needs to turn it to a vector before normalizing

            return worldNormal.Normalize().AsVector();
        }

        public override bool Equals(object obj)
        {
            var sphere = obj as Sphere;
            return sphere != null &&
                   EqualityComparer<Matrix>.Default.Equals(Transform, sphere.Transform) &&
                   EqualityComparer<Material>.Default.Equals(Material, sphere.Material);
        }

        public override int GetHashCode()
        {
            var hashCode = -2065766541;
            hashCode = hashCode * -1521134295 + EqualityComparer<Matrix>.Default.GetHashCode(Transform);
            hashCode = hashCode * -1521134295 + EqualityComparer<Material>.Default.GetHashCode(Material);
            return hashCode;
        }
    }

}
