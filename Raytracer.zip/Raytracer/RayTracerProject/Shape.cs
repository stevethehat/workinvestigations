﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public abstract class Shape
    {
        public Matrix Transform { get; set; }
        public Material Material { get; set; }


        public Shape()
        {
            Transform = Matrix.Identity();
            Material = new Material();
      
        }

        public Vector NormalAt(Point point)
        {
            var localPoint = (Transform.Invert() * point);
            var localNormal = LocalNormalAt(localPoint);
            //var objectNormal = objectPoint - new Point(0, 0, 0);
            var worldNormal = (Transform.Invert().Transpose() * localNormal);

            worldNormal.W = 0; // Needs to turn it to a vector before normalizing

            return worldNormal.Normalize().AsVector();
        }


        public Intersections Intersect(Ray ray)
        {
  
            var localRay = ray.Transform(this.Transform.Invert());
            return LocalIntersect(localRay);
        }

        public abstract Intersections LocalIntersect(Ray ray);
        public abstract RTuple LocalNormalAt(RTuple point);

        public override bool Equals(object obj)
        {
            var shape = obj as Shape;
            return shape != null &&
                   EqualityComparer<Matrix>.Default.Equals(Transform, shape.Transform) &&
                   EqualityComparer<Material>.Default.Equals(Material, shape.Material);
        }

        public override int GetHashCode()
        {
            var hashCode = -2065766541;
            hashCode = hashCode * -1521134295 + EqualityComparer<Matrix>.Default.GetHashCode(Transform);
            hashCode = hashCode * -1521134295 + EqualityComparer<Material>.Default.GetHashCode(Material);
            return hashCode;
        }

       
    }
}
