﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{


    public class Vector : RTuple
    {
        public Vector(double x, double y, double z) : base(x, y, z, 0)
        {
        }
    }

    public class Point : RTuple
    {
        public Point(double x, double y, double z) : base(x, y, z, 1.0)
        {
        }
    }

    public class RTuple
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double W { get; set; }

        public RTuple(double x, double y, double z, double w)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.W = w;
        }

        public static Point Point(double x, double y, double z)
        {
            return new Point(x, y, z);
        }

        public static Vector Vector(double x, double y, double z)
        {
            return new Vector(x, y, z);
        }

        public static RTuple operator +(RTuple left, RTuple right)
        {
            return new RTuple(
                left.X + right.X,
                left.Y + right.Y,
                left.Z + right.Z,
                left.W + right.W);
        }

        public static RTuple operator -(RTuple left, RTuple right)
        {
            return new RTuple(
                left.X - right.X,
                left.Y - right.Y,
                left.Z - right.Z,
                left.W - right.W);
        }

        public static RTuple operator -(RTuple left)
        {
            return new RTuple(
                left.X = -left.X,
                left.Y = -left.Y,
                left.Z = -left.Z,
                left.W = -left.W);
        }

        public static RTuple operator *(RTuple left, double value)
        {
            return new RTuple(
                left.X * value,
                left.Y * value,
                left.Z * value,
                left.W * value);
        }

        public static RTuple operator /(RTuple left, double value)
        {
            return new RTuple(
                left.X / value,
                left.Y / value,
                left.Z / value,
                left.W / value);
        }

        public static bool operator ==(RTuple left, RTuple right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(RTuple left, RTuple right)
        {
            return !Equals(left, right);
        }

        public bool IsPoint()
        {
            return W == 1.0f;
        }

        public bool IsVector()
        {
            return W == 0.0f;
        }

        public double Magnitude()
        {
            return Math.Sqrt((X * X) + (Y * Y) + (Z * Z) + (W * W));
        }

        public RTuple Normalize()
        {
            double magnitude = Magnitude();

            return new RTuple(
                (X / magnitude),
                Y / magnitude,
                Z / magnitude,
                W / magnitude
            );
        }

        public double Dot(RTuple other)
        {
            return X * other.X +
                Y * other.Y +
                Z * other.Z +
                W * other.W;
        }

        public RTuple Cross(RTuple other)
        {
            return Vector(
                Y * other.Z - Z * other.Y,
                Z * other.X - X * other.Z, 
                X * other.Y - Y * other.X);
        }

        public RTuple Reflect(RTuple normal)
        {
            //var step1 = (this - normal);
            //var step2 = step1 * 2;
            //var step3 = Dot(normal);
            //var step4 = step2 * step3;
            return this - normal * 2.0 * Dot(normal);
        }

        public double[] ToArray()
        {
            return new double[] { X, Y, Z, W };
        }

        public static RTuple FromArray(double[] value)
        {
            return new RTuple(value[0], value[1], value[2], value[3]);
        }

        public override bool Equals(object obj)
        {

            const double EPSILON = 0.0001;

            if (!(obj is RTuple))
            {
                return false;
            }

            var tuple = (RTuple)obj;
            return Math.Abs(X - tuple.X) < EPSILON &&
                   Math.Abs(Y - tuple.Y) < EPSILON &&
                   Math.Abs(Z - tuple.Z) < EPSILON &&
                   Math.Abs(W - tuple.W) < EPSILON;
        }

        public override int GetHashCode()
        {
            var hashCode = 707706286;
            hashCode = hashCode * -1521134295 + X.GetHashCode();
            hashCode = hashCode * -1521134295 + Y.GetHashCode();
            hashCode = hashCode * -1521134295 + Z.GetHashCode();
            hashCode = hashCode * -1521134295 + W.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return $"X: {X}, Y:{Y}, Z:{Z}, W:{W}";
        }

        public Point AsPoint()
        {
            return new Point(X, Y, Z);
        }

        public Vector AsVector()
        {
            return new Vector(X, Y, Z);
        }
    }

}
