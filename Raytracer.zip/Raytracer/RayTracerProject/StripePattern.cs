﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class StripePattern: Pattern
    {
        public RColor ColorA { get; private set; }
        public RColor ColorB { get; private set; }
        public StripePattern(RColor colorA, RColor colorB)
        {
            ColorA = colorA;
            ColorB = colorB;
        }
         
        public override RColor ColorAt(Point point)
        {
            if(Math.Floor(point.X) % 2 == 0)
            {
                return ColorA;
            } else
            {
                return ColorB;
            }
        }
        

    }
}
