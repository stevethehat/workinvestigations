﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Ray
    {

        public Ray(Point origin, Vector direction)
        {
            Origin = origin;
            Direction = direction;
        }

        public Point Origin { get; }
        public Vector Direction { get; }

        public Point Position(double time)
        {
            return (Origin + Direction * time).AsPoint();
        }

        public Intersections Intersect(Sphere sphere)
        {
            Intersections intersections = new Intersections();
            var ray2 = this.Transform(sphere.Transform.Invert());

            var sphereToRay = ray2.Origin - new Point(0, 0, 0);
            var a = ray2.Direction.Dot(ray2.Direction);
            var b = 2 * ray2.Direction.Dot(sphereToRay);
            var c = sphereToRay.Dot(sphereToRay) - 1;

            var discriminant = b * b - 4 * a * c;

            if(discriminant > -1)
            {
                var t1 = (-b - Math.Sqrt(discriminant)) / (2 * a);
                var t2 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                var time1 = new Intersection(t1, sphere);
                var time2 = new Intersection(t2, sphere);


                if (t1 > t2)
                {
                    intersections.Add(time2);
                    intersections.Add(time1);
                } else
                {
                    intersections.Add(time1);
                    intersections.Add(time2);
                }
            }


            return intersections;
        }

        public Ray Transform(Matrix matrix)
        {
            var newOrigin = (matrix * Origin).AsPoint();
            var newDirection = (matrix * Direction).AsVector();
            return new Ray(newOrigin, newDirection);
        }
    }
}
