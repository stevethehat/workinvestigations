﻿using System.Collections.Generic;

namespace RayTracerProject
{
    public class PPMFile{

        protected readonly Canvas canvas;
        protected List<string> lines;
        private const int MAX_COLOR = 255;
        private const int MAX_LINE_LENGTH = 70;
        public PPMFile(Canvas canvas)
        {
            this.canvas = canvas;
        }

        public string Generate()
        {
            lines = new List<string>
            {
                "P3",
                $"{canvas.Width} {canvas.Height}",
                MAX_COLOR.ToString()
            };

            for (int y = 0; y < canvas.Height; y++)
            {
                string currentLine = "";
                for (int x = 0; x < canvas.Width; x++)
                {
                    currentLine += GetColorString(canvas[x, y]);

                    if(currentLine.Length > MAX_LINE_LENGTH)
                    {
                        int breakPos = currentLine.LastIndexOf(' ', MAX_LINE_LENGTH);
                        lines.Add(currentLine.Substring(0, breakPos));
                        currentLine = currentLine.Substring(breakPos + 1);
                    }
                }

                if (currentLine.Length > 0)
                {
                    lines.Add(currentLine.Substring(0, currentLine.Length - 1));
                }
            }

            return string.Join("\r",lines) + "\r";
        }

        private string GetColorString(RColor color)
        {
            return $"{color.RInt} {color.GInt} {color.BInt} ";
        }

    }
}
