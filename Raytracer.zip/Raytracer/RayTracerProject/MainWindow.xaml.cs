﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RayTracerProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Canvas canvas;

        public MainWindow()
        {
            InitializeComponent();

            var start = new Point(0, 1, 0);
            var velocity = (new Vector(1, 1.8, 0) * 600.25).Normalize();
            var projectile = new Projectile(start, velocity);

            var gravity = new Vector(0, -0.0081, 0);
            var wind = new Vector(0.01, 0, 0);
            var world = new World(gravity, wind);

            canvas = new Canvas(900, 550);
            RColor red = new RColor(1.0, 0, 0);

            for (int i = 0; i < 600; i++)
            {
                Tick(world, projectile);

                //Maincanvas.Text += $"projectile Pos: {projectile.Position.ToString()} Vel: {projectile.Velocity.ToString()} \n";
                int xPos = (int)projectile.Position.X;
                int yPos = canvas.Height - (int)projectile.Position.Y;

                if ((xPos > 0 && xPos < canvas.Width) && (yPos > 0 && yPos < canvas.Height))
                {
                    canvas[xPos, yPos] = red;
                }

                
            }
            MakeImage(canvas);

        }

        private void Tick(World w, Projectile p)
        {
            var position = p.Position + p.Velocity;
            var velocity = p.Velocity + w.Gravity + w.Wind;

            p.Position = position;
            p.Velocity = velocity;

            //mainImage.Source =  
        }

        private void MakeImage(Canvas c)
        {
            MemoryStream ms = new MemoryStream();
   
            Bitmap bitmap =  new Bitmap(c.Width,c.Height);
            for (int x = 0; x < c.Width; x++)
            {
                for (int y = 0; y < c.Height; y++)
                {

                    RColor color = c[x, y];
                    bitmap.SetPixel(x, y, System.Drawing.Color.FromArgb(color.RInt, color.GInt, color.BInt));
                }
            }

            bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            ms.Seek(0, SeekOrigin.Begin);
            image.StreamSource = ms;
            image.EndInit();

            mainImage.Source = image;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "Image",
                DefaultExt = ".ppm", 
                Filter = "Image Files (.ppm)|*.ppm"
            };

            Nullable<bool> result = dlg.ShowDialog();
            if(result == true)
            {
                var ppm = new PPMFile(canvas);
                File.WriteAllText(dlg.FileName, ppm.Generate());
            }
        }
    }

    public class World
    {
        public RTuple Gravity { get; set; }
        public RTuple Wind { get; set; }


        public World(RTuple gravity, RTuple wind)
        {
            Gravity = gravity;
            Wind = wind;
        }
    }

    public class Projectile
    {
        public RTuple Position { get; set; }
        public RTuple Velocity { get; set; }

        public Projectile(RTuple position, RTuple velocity)
        {
            Position = position;
            Velocity = velocity;
        }
    }
}
