﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RayTracerProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Canvas canvas;

        public void VelovityTest()
        {
            var start = new Point(0, 1, 0);
            var velocity = (new Vector(1, 1.8, 0) * 600.25).Normalize();
            var projectile = new Projectile(start, velocity);

            var gravity = new Vector(0, -0.0081, 0);
            var wind = new Vector(0.01, 0, 0);
            var world = new SimpleWorld(gravity, wind);

            canvas = new Canvas(900, 550);
            RColor red = new RColor(1.0, 0, 0);

            for (int i = 0; i < 600; i++)
            {
                Tick(world, projectile);

                //Maincanvas.Text += $"projectile Pos: {projectile.Position.ToString()} Vel: {projectile.Velocity.ToString()} \n";
                int xPos = (int)projectile.Position.X;
                int yPos = canvas.Height - (int)projectile.Position.Y;

                if ((xPos > 0 && xPos < canvas.Width) && (yPos > 0 && yPos < canvas.Height))
                {
                    canvas[xPos, yPos] = red;
                }


            }
        }

        public void Clock() {
            int size = 250;
            canvas = new Canvas(900, 550);
            RColor red = new RColor(1.0, 0, 0);

            RTuple point = new Point(0, 1, 0);
            double rotateBy = Math.PI / 6;
            Matrix rotationMatrix = Matrix.RotateZ(rotateBy);
            Matrix scaleMatrix = Matrix.Scale(size, size, size);

            for (int i = 0; i < 12; i++)
            {
                point = rotationMatrix * point;
                RTuple realPoint = scaleMatrix * point;
                DrawDot((int)realPoint.X, (int)realPoint.Y, red, 4);
            }
            canvas.DrawFromOrigin(0, 0, red);

            point = new Point(0, 1, 0);
            for (int i = 0; i < size; i++)
            {
                scaleMatrix = Matrix.Scale(i, -i, i);
                RTuple realPoint = scaleMatrix * point;
                canvas.DrawFromOrigin((int)realPoint.X, (int)realPoint.Y, red);
            }


            MakeImage(canvas);
        }

        public void Sphere()
        {
            double wallWidth = 7;
            double wallHeight = 7;
            double wallZ = 10;
            int canvasWidth = 600;
            int canvasHeight = 600;
            double pixelSize = (double)wallWidth / (double)canvasWidth;

            canvas = new Canvas(canvasWidth, canvasHeight);

            Sphere sphere = new Sphere();
            Point origin = new Point(0, 0, -5);
            Light light = new PointLight(new Point(10, 10, -10), new RColor(1, 1, 1));

            sphere.Material.Color = new RColor(1, 0.2, 1);
            //sphere.Transform = Matrix.Scale(1, 0.5, 0.5);

            double half = (wallHeight / 2.0);

            for (int canvasY = 0; canvasY < canvasHeight; canvasY++)
            {
                double worldY = half - pixelSize * canvasY;
                for (int canvasX = 0; canvasX < canvasWidth; canvasX++)
                {
                    double worldX = half - pixelSize * canvasX;
                    Point wallPoint = new Point(worldX, worldY, wallZ);
                    Vector trajectory = (wallPoint - origin).Normalize().AsVector();
                    Ray ray = new Ray(origin, trajectory);

                    Intersections intersections = sphere.Intersect(ray);
                    Intersection hit = intersections.GetHit();

                    if (hit != default(Intersection))
                    {
                        var point = ray.Position(hit.Time);
                        var normal = hit.Shape.NormalAt(point);
                        var eye = ray.Direction;
                        var color = hit.Shape.Material.Lighting(light, point, eye, normal);
                        canvas[canvasX, canvasY] = color;
                    }
                }
            }

            MakeImage(canvas);
        }

        public MainWindow()
        {
            InitializeComponent();

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            World world = new World();

            Plane floor = new Plane();
            floor.Transform = Matrix.Translation(0,0,-5);
            floor.Material.Color = new RColor(0.5, 0.5, 0.5);
            floor.Material.Specular = 0;
            //floor.Material.Pattern = new GradientRing(new RColor(1, 0, 0), new RColor(0, 1, 0));
            StripePattern p1 = new StripePattern(new RColor(0, 1, 0), new RColor(1, 1, 1));
            StripePattern p2 = new StripePattern(new RColor(0, 1, 0), new RColor(1, 1, 1));
            p2.Transform = Matrix.RotateY(Math.PI / 2);
            floor.Material.Pattern = new BlendedPattern(p1,p2);


            Plane wall = new Plane();
            wall.Transform = Matrix.RotateX(Math.PI / 2)
                * Matrix.Translation(0, 5, 0);
            wall.Material.Color = new RColor(0.5, 0.5, 0.5);
            wall.Material.Specular = 0;
            wall.Material.Reflective = 1;

            

            /*
            Sphere leftWall = new Sphere();
            leftWall.Transform = Matrix.Translation(0, 0, 5)
                * Matrix.RotateY(-Math.PI / 4)
                * Matrix.RotateX(Math.PI / 2)
                * Matrix.Scale(10, 0.01, 10);
            leftWall.Material = floor.Material;

            Sphere rightWall = new Sphere();
            rightWall.Transform = Matrix.Translation(0, 0, 5)
                * Matrix.RotateY(Math.PI / 4)
                * Matrix.RotateX(Math.PI / 2)
                * Matrix.Scale(10, 0.01, 10);
            rightWall.Material = floor.Material;
            */

            Sphere middle = new Sphere();
            middle.Transform = Matrix.Translation(-0.5, 1, 0.5);
            middle.Material.Color = new RColor(0.8, 0.8, 0.8);
            middle.Material.Diffuse = 0.2;
            middle.Material.Specular = 0.3;
            middle.Material.Ambient = 0.1;
            //middle.Material.Pattern = new StripePattern(new RColor(0, 1, 0), new RColor(1, 1, 1));
            middle.Material.Reflective = 1;
            middle.Material.Transparency = 0.9;

            Sphere right = new Sphere();
            right.Transform = Matrix.Translation(1.5, 0.5, -0.5) 
                * Matrix.Scale(0.5, 0.5, 0.5);
            //right.Material.Color = new RColor(1, 0, 0.1);
            right.Material.Color = new RColor(0.2, 0.2, 0.2);
            right.Material.Diffuse = 0.4;
            right.Material.Specular = 0.3;
            right.Material.Reflective = 0.6;
            //right.Material.Pattern = new StripePattern(new RColor(0, 1, 0), new RColor(1, 1, 1));
            //right.Material.Pattern.Transform = Matrix.Scale(5, 5, 5);

            Sphere left = new Sphere();
            left.Transform = Matrix.Translation(-1.2, 0.33, -0.85)
                * Matrix.Scale(0.33, 0.33, 0.33);
            left.Material.Color = new RColor(1, 0.1, 0.1);
            left.Material.Diffuse = 0.7;
            left.Material.Specular = 0.3;


            Sphere back = new Sphere();
            back.Transform = Matrix.Translation(-1.5, 0.8, 2.5)
                * Matrix.Scale(0.8, 0.8, 0.8);
            back.Material.Color = new RColor(1, 1, 0.1);
            back.Material.Diffuse = 0.7;
            back.Material.Specular = 0.3;

            Sphere back2 = new Sphere();
            back2.Transform = Matrix.Translation(1.5, 2.4, 2.5)
                * Matrix.Scale(1.4, 1.4, 1);
            back2.Material.Color = new RColor(1, 0.55, 0
                );
            back2.Material.Shininess = 300;
            back2.Material.Specular = 1;
            back2.Material.Reflective = 0.6;

            //left.Material.Pattern = new CheckersPattern(new RColor(0, 1, 0), new RColor(1, 1, 1));


            world.Objects.Add(back);
            world.Objects.Add(back2);
            world.Objects.Add(floor);
            //world.Objects.Add(wall);
            world.Objects.Add(middle);
            world.Objects.Add(right);
            world.Objects.Add(left);

            world.Lights.Add(
                new PointLight(new Point(-10, 10, -10), new RColor(1, 1, 1))
            );

            Camera camera = new Camera(600, 600, Math.PI / 3);
            camera.Transform = Matrix.ViewTransform(
                new Point(0, 1.5, -5),
                new Point(0, 1, 0),
                new Vector(0, 1, 0)
            );

            canvas = camera.ParallelRender(world);
            MakeImage(canvas);
        }

        public void Spheres()
        {
            World world = new World();

            Sphere floor = new Sphere();
            floor.Transform = Matrix.Scale(10, 0.01, 10);
            floor.Material.Color = new RColor(1, 0.9, 0.9);
            floor.Material.Specular = 0;


            Sphere leftWall = new Sphere();
            leftWall.Transform = Matrix.Translation(0, 0, 5)
                * Matrix.RotateY(-Math.PI / 4)
                * Matrix.RotateX(Math.PI / 2)
                * Matrix.Scale(10, 0.01, 10);
            leftWall.Material = floor.Material;

            Sphere rightWall = new Sphere();
            rightWall.Transform = Matrix.Translation(0, 0, 5)
                * Matrix.RotateY(Math.PI / 4)
                * Matrix.RotateX(Math.PI / 2)
                * Matrix.Scale(10, 0.01, 10);
            rightWall.Material = floor.Material;

            Sphere middle = new Sphere();
            middle.Transform = Matrix.Translation(-0.5, 1, 0.5);
            middle.Material.Color = new RColor(0.1, 1, 0.5);
            middle.Material.Diffuse = 0.7;
            middle.Material.Specular = 0.3;

            Sphere right = new Sphere();
            right.Transform = Matrix.Translation(1.5, 0.5, -0.5)
                * Matrix.Scale(0.5, 0.5, 0.5);
            right.Material.Color = new RColor(1, 0, 0.1);
            right.Material.Diffuse = 0.7;
            right.Material.Specular = 0.3;

            Sphere left = new Sphere();
            left.Transform = Matrix.Translation(-1.5, 0.33, -0.75)
                * Matrix.Scale(0.33, 0.33, 0.33);
            left.Material.Color = new RColor(1, 0.8, 0.1);
            left.Material.Diffuse = 0.7;
            left.Material.Specular = 0.3;

            world.Objects.Add(floor);
            world.Objects.Add(leftWall);
            world.Objects.Add(rightWall);
            world.Objects.Add(middle);
            world.Objects.Add(right);
            world.Objects.Add(left);

            world.Lights.Add(
                new PointLight(new Point(-10, 10, -10), new RColor(1, 1, 1))
            );

            Camera camera = new Camera(300, 300, Math.PI / 3);
            camera.Transform = Matrix.ViewTransform(
                new Point(0, 1.5, -5),
                new Point(0, 1, 0),
                new Vector(0, 1, 0)
            );

            canvas = camera.ParallelRender(world);
            //Title = $"Rendered in {stopwatch.Elapsed}";

            MakeImage(canvas);

        }
        private void DrawSilhouette()
        {
            double wallWidth = 7;
            double wallHeight = 7;
            double wallZ = 10;
            int canvasWidth = 300;
            int canvasHeight = 300;
            double pixelSize = (double)wallWidth / (double)canvasWidth;

            canvas = new Canvas(canvasWidth, canvasHeight);
            RColor red = new RColor(1.0, 0, 0);
            RColor blue = new RColor(0, 0, 1);

            Sphere sphere = new Sphere();
            Point origin = new Point(0, 0, -5);

            //for (int canvasY = 0; canvasY < canvasHeight; canvasY++)
            //{
            //    for (int canvasX = 0; canvasX < canvasWidth; canvasX++)
            //    {
            //        canvas[canvasX, canvasY] = blue;
            //    }
            //}

            double half = (wallHeight / 2.0);

            for (int canvasY = 0; canvasY < canvasHeight; canvasY++)
            {
                double worldY = half - pixelSize * canvasY;
                for (int canvasX = 0; canvasX < canvasWidth; canvasX++)
                {
                    double worldX = half - pixelSize * canvasX;
                    Point wallPoint = new Point(worldX, worldY, wallZ);
                    Vector trajectory = (wallPoint - origin).Normalize().AsVector();
                    Ray ray = new Ray(origin, trajectory);

                    Intersections intersections = sphere.Intersect(ray);
                    Intersection hit = intersections.GetHit();

                    if (hit != default(Intersection))
                    {
                        canvas[canvasX, canvasY] = red;
                    }
                }
            }

            /*
            for(int wallX = - wallWidth / 2; wallX < wallWidth / 2; wallX++)
            {
                for (int wallY = - wallHeight / 2; wallY < wallHeight / 2; wallY++)
                {
                    Point wallPoint = new Point(wallX, wallY, wallZ);
                    Vector trajectory = (wallPoint - origin).Normalize().AsVector();
                    Ray ray = new Ray(origin, trajectory);
                    Intersections intersections = ray.Intersect(sphere);
                    Intersection hit = intersections.GetHit();

                    if(hit != default(Intersection))
                    {
                        //DrawDot(wallX, wallY, red, pixelSize);
                        canvas.DrawFromOrigin(wallX, wallY, red);
                    }
                }
            }*/

            MakeImage(canvas);
        }

        private void DrawDot(int x, int y, RColor color, int scale)
        {
            scale = scale / 2;
            for (int x2= x - scale; x2 < x + scale; x2++)
            {
                for (int y2 = y - scale; y2 < y + scale; y2++)
                {
                    canvas.DrawFromOrigin(x2, y2, color);
                }
            }

            
        }

        private void Tick(SimpleWorld w, Projectile p)
        {
            var position = p.Position + p.Velocity;
            var velocity = p.Velocity + w.Gravity + w.Wind;

            p.Position = position;
            p.Velocity = velocity;

            //mainImage.Source =  
        }

        private void MakeImage(Canvas c)
        {
            MemoryStream ms = new MemoryStream();
   
            Bitmap bitmap =  new Bitmap(c.Width,c.Height);
            for (int x = 0; x < c.Width; x++)
            {
                for (int y = 0; y < c.Height; y++)
                {

                    RColor color = c[x, y];
                    bitmap.SetPixel(x, y, System.Drawing.Color.FromArgb(color.RInt, color.GInt, color.BInt));
                }
            }

            bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            ms.Seek(0, SeekOrigin.Begin);
            image.StreamSource = ms;
            image.EndInit();

            mainImage.Source = image;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "Image",
                DefaultExt = ".ppm", 
                Filter = "Image Files (.ppm)|*.ppm"
            };

            Nullable<bool> result = dlg.ShowDialog();
            if(result == true)
            {
                var ppm = new PPMFile(canvas);
                File.WriteAllText(dlg.FileName, ppm.Generate());
            }
        }
    }

    public class SimpleWorld
    {
        public RTuple Gravity { get; set; }
        public RTuple Wind { get; set; }


        public SimpleWorld(RTuple gravity, RTuple wind)
        {
            Gravity = gravity;
            Wind = wind;
        }
    }

    public class Projectile
    {
        public RTuple Position { get; set; }
        public RTuple Velocity { get; set; }

        public Projectile(RTuple position, RTuple velocity)
        {
            Position = position;
            Velocity = velocity;
        }
    }
}
