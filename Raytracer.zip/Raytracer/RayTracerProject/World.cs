﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class World
    {
        public List<Shape> Objects;
        public List<Light> Lights;
        public World()
        {
            Objects = new List<Shape>();
            Lights = new List<Light>();
        }

        public Intersections Intersect(Ray ray)
        {
            Intersections result = new Intersections();

            foreach(var obj in Objects){
                result.AddRange(obj.Intersect(ray));
            };

            return new Intersections(result.OrderBy(i => i.Time).ToList<Intersection>());
        }

        public RColor ShadeHit(Intersection hit, int remaining = 5)
        {
            RColor result;
            RColor surface = new RColor();
            if (Lights.Any())
            {
                bool isShadowed = IsShadowed(hit.Point);
                surface = hit.Shape.Material.Lighting(Lights[0], hit, isShadowed);
            }

            RColor reflected = ReflectedColor(hit, remaining);
            RColor refracted = RefractedColor(hit, remaining);

            Material material = hit.Shape.Material;
            if(material.Reflective > 0 && material.Transparency > 0)
            {
                double reflectance = hit.Schlick();
                result = surface + reflected * reflectance + refracted * (1.0 - reflectance);
            }
            else
            {
                result = surface + reflected + refracted;
            }

            return result;
        }

        public bool IsShadowed(Point point)
        {
            Intersection hit = null;
            double distance = 0;

            if (Lights.Any())
            {
                RTuple v = Lights[0].Position - point;
                distance = v.Magnitude();
                Vector direction = v.Normalize().AsVector();

                Ray ray = new Ray(point, direction);
                Intersections intersections = Intersect(ray);

                hit = intersections.GetHit();
            }

            if(hit != default(Intersection) && hit.Time < distance)
            {
                return true;
            } else
            {
                return false;
            }
        }

        public RColor ColorAt(Ray ray, int remaining = 5)
        {
            RColor result;
            Intersections intersections = Intersect(ray);
            Intersection hit = intersections.GetHit();
            if(hit != default(Intersection))
            {
                hit.PrepareHit(ray, intersections);
                result = ShadeHit(hit, remaining);
            } else
            {
                result = new RColor(0, 0, 0);
            }
            return result;
        }

        public RColor ReflectedColor(Intersection hit, int remaining)
        {
            if(hit.Shape.Material.Reflective == 0 || remaining == 0)
            {
                return new RColor(0, 0, 0);
            }
            Ray reflect_ray = new Ray(hit.Point, hit.Reflected);
            RColor color = ColorAt(reflect_ray, --remaining);
            RColor result = color * hit.Shape.Material.Reflective;
            return result;
        }

        public RColor RefractedColor(Intersection hit, int remaining)
        {
            if (hit.Shape.Material.Transparency == 0 || remaining == 0)
            {
                return new RColor(0, 0, 0);
            }

            double ratio = hit.N1 / hit.N2;
            double cosI = hit.Eye.Dot(hit.Normal);
            double sin2T = Math.Pow(ratio, 2d) * (1d - Math.Pow(cosI, 2d));

            if(sin2T > 1)
            {
                return new RColor();
            }

            double cosT = Math.Sqrt(1d - sin2T);
            RTuple direction = hit.Normal * (ratio * cosI - cosT) - hit.Eye * ratio;
            Ray refractedRay = new Ray(hit.UnderPoint, direction.AsVector());

            RColor color = ColorAt(refractedRay, --remaining) * hit.Shape.Material.Transparency;

            return color;
        }


        public static World Default()
        {
            World result = new World();
            result.Lights.Add(new PointLight(new Point(-10, 10, -10), new RColor(1, 1, 1)));
            Sphere sphere = new Sphere()
            {
                Material = new Material()
                {
                    Color = new RColor(0.8, 1.0, 0.6),
                    Diffuse = 0.7,
                    Specular = 0.2
                }
            };

            result.Objects.Add(sphere);

            sphere = new Sphere();
            sphere.Transform = Matrix.Scale(0.5, 0.5, 0.5);
            result.Objects.Add(sphere);

            return result;
        }
    }
}
