﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class World
    {
        public List<Shape> Objects;
        public List<Light> Lights;
        public World()
        {
            Objects = new List<Shape>();
            Lights = new List<Light>();
        }

        public Intersections Intersect(Ray ray)
        {
            Intersections result = new Intersections();

            foreach(var obj in Objects){
                result.AddRange(obj.Intersect(ray));
            };

            return new Intersections(result.OrderBy(i => i.Time).ToList<Intersection>());
        }

        public RColor ShadeHit(Intersection hit)
        {
            bool isShadowed = IsShadowed(hit.Point);
            return hit.Shape.Material.Lighting(Lights[0], hit.Point, hit.Eye, hit.Normal, isShadowed);
        }

        public bool IsShadowed(Point point)
        {
            RTuple v = Lights[0].Position - point;
            double distance = v.Magnitude();
            Vector direction = v.Normalize().AsVector();

            Ray ray = new Ray(point, direction);
            Intersections intersections = Intersect(ray);

            Intersection hit = intersections.GetHit();

            if(hit != default(Intersection) && hit.Time < distance)
            {
                return true;
            } else
            {
                return false;
            }
        }

        public RColor ColorAt(Ray ray)
        {
            RColor result;
            Intersections intersections = Intersect(ray);
            Intersection hit = intersections.GetHit();
            if(hit != default(Intersection))
            {
                hit.PerpareHit(ray);
                result = ShadeHit(hit);
            } else
            {
                result = new RColor(0, 0, 0);
            }
            return result;
        }


        public static World Default()
        {
            World result = new World();
            result.Lights.Add(new PointLight(new Point(-10, 10, -10), new RColor(1, 1, 1)));
            Sphere sphere = new Sphere()
            {
                Material = new Material()
                {
                    Color = new RColor(0.8, 1.0, 0.6),
                    Diffuse = 0.7,
                    Specular = 0.2
                }
            };

            result.Objects.Add(sphere);

            sphere = new Sphere();
            sphere.Transform = Matrix.Scale(0.5, 0.5, 0.5);
            result.Objects.Add(sphere);

            return result;
        }
    }
}
