﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Intersection
    {
        public Intersection(double time, Shape shape)
        {
            Time = time;
            Shape = shape;
        }

        public double Time { get; }
        public Shape Shape { get; }
  
        public Point Point { get; private set; }
        public Point UnderPoint { get; private set; }
        public Vector Eye { get; private set; }
        public Vector Normal { get; private set; }
        public Vector Reflected { get; private set; }
        public double N1 { get; private set; }
        public double N2 { get; private set; }

        public bool Inside { get; private set; }

        private double GetNValue(List<Shape> shapes)
        {
            double result = 1;
            if (shapes.Any())
            {
                result = shapes.Last().Material.RefractiveIndex;
            }

            return result;
        }
        public void PrepareHit(Ray ray, Intersections intersections)
        {
            PrepareHit(ray);
            List<Shape> shapes = new List<Shape>();

            foreach(var intersection in intersections)
            {
                if(intersection == this)
                {
                    this.N1 = GetNValue(shapes);
                }

                if (shapes.Contains(intersection.Shape))
                {
                    shapes.Remove(intersection.Shape);
                }
                else
                {
                    shapes.Add(intersection.Shape);
                }

                if (intersection == this)
                {
                    this.N2 = GetNValue(shapes);
                    break;
                }
            }
        }

        public void PrepareHit(Ray ray)
        {
            Point = ray.Position(Time);
            Eye = (-ray.Direction).AsVector();
            Normal = Shape.NormalAt(Point);
            Reflected = (-ray.Direction).Reflect(Normal).AsVector();
                           
            
            if (Normal.Dot(Eye) < 0)
            {
                Inside = true;
                Normal = (-Normal).AsVector();
            } 
            else
            {
                Inside = false;
            }
            //hit.point ← hit.point + hit.normalv * 0.0001
            UnderPoint = (Point - Normal * 0.0001d).AsPoint();
            Point = (Point + Normal * 0.0001d).AsPoint();
            

        }

        public double Schlick()
        {
            double result = 0;
            double cos = Eye.Dot(Normal);

            if(N1 > N2)
            {
                double n = N1 / N2;
                double sin2_t = Math.Pow(n, 2) * (1.0 - Math.Pow(cos, 2));
                if(sin2_t > 1.0)
                {
                    return 1;
                }
                else
                {
                    double cos_t = Math.Sqrt(1.0 - sin2_t);

                    cos = cos_t;
                }
            }

            double r0 = Math.Pow((N1 - N2) / (N1 + N2), 2);
            result = r0 + (1 - r0) * Math.Pow(1 - cos, 5);
            return result;
        }

        public void PrepareComputations(Ray ray)
        {
            PrepareHit(ray);
        }

        public override string ToString()
        {
            return $"Time: {Time}";
        }
    }
}
