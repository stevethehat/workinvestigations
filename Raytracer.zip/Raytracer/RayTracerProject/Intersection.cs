﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Intersection
    {
        public Intersection(double time, Sphere shape)
        {
            Time = time;
            Shape = shape;
        }

        public double Time { get; }
        public Sphere Shape { get; }
  
        public Point Point { get; private set; }
        public Vector Eye { get; private set; }
        public Vector Normal { get; private set; }

        public bool Inside { get; private set; }

        public void PerpareHit(Ray ray)
        {
            Point = ray.Position(Time);
            Eye = (-ray.Direction).AsVector();
            Normal = Shape.NormalAt(Point);

            if(Normal.Dot(Eye) < 0)
            {
                Inside = true;
                Normal = (-Normal).AsVector();
            } 
            else
            {
                Inside = false;
            }

        }

        public override string ToString()
        {
            return $"Time: {Time}";
        }
    }
}
