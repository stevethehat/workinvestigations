﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Intersections : List<Intersection>
    {

        public Intersections(IEnumerable<Intersection> intersections): base(intersections){}
        public Intersections() : base() { }

        public Intersection GetHit()
        {
            return this.Aggregate(default(Intersection), (prod, next) =>
            {
                if (next.Time >= 0 && (prod == default(Intersection) || next.Time < prod.Time)) {
                    return next;
                }
                return prod;
            });
           
        }

    }
}
