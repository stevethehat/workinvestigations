﻿using System;

namespace RayTracerProject
{
    public struct RColor
    {

        private const int MAX_COLOR = 255;

        public double R { get; set; }
        public double G { get; set; }
        public double B { get; set; }

        public int RInt
        {
            get => GeIntColor(R);
        }

        public int GInt
        {
            get => GeIntColor(G);
        }
        public int BInt
        {
            get => GeIntColor(B);
        }

        public RColor(double r, double g, double b)
        {
            R = r;
            G = g;
            B = b;
        }


        private int GeIntColor(double value)
        {
            int returnValue = (int)Math.Ceiling(value * MAX_COLOR);
            if (returnValue > MAX_COLOR)
            {
                returnValue = MAX_COLOR;
            }
            else if (returnValue < 0)
            {
                returnValue = 0;
            }

            return returnValue;
        }

        public static RColor operator +(RColor left, RColor right)
        {
            return new RColor(
                left.R + right.R,
                left.G + right.G,
                left.B + right.B);
        }

        public static RColor operator -(RColor left, RColor right)
        {
            return new RColor(
                left.R - right.R,
                left.G - right.G,
                left.B - right.B);
        }

        public static RColor operator *(RColor left, double value)
        {
            return new RColor(
                left.R * value,
                left.G * value,
                left.B * value);
        }

        public static RColor operator *(RColor left, RColor right)
        {
            return new RColor(
                left.R * right.R,
                left.G * right.G,
                left.B * right.B);
        }

        public static bool operator ==(RColor left, RColor right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(RColor left, RColor right)
        {
            return !Equals(left, right);
        }

        public override bool Equals(object obj)
        {
            const double EPSILON = 0.00001;

            if (!(obj is RColor))
            {
                return false;
            }

            var tuple = (RColor)obj;
            return Math.Abs(R - tuple.R) < EPSILON &&
                   Math.Abs(G - tuple.G) < EPSILON &&
                   Math.Abs(B - tuple.B) < EPSILON;
        }

        public override int GetHashCode()
        {
            var hashCode = -1520100960;
            hashCode = hashCode * -1521134295 + R.GetHashCode();
            hashCode = hashCode * -1521134295 + G.GetHashCode();
            hashCode = hashCode * -1521134295 + B.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return $"R:{R},G:{G},B:{B}";
        }
    }

}
