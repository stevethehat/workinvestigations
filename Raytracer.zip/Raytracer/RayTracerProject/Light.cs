﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class PointLight : Light
    {
        public PointLight(Point position, RColor intensity) : base(position, intensity)
        {

        }

    }

    public class Light
    {
        public Light(Point position, RColor intensity)
        {
            Position = position;
            Intensity = intensity;
        }
        public Point Position { get; }
        public RColor Intensity { get; }

        public override bool Equals(object obj)
        {
            var light = obj as Light;
            return light != null &&
                   EqualityComparer<Point>.Default.Equals(Position, light.Position) &&
                   EqualityComparer<RColor>.Default.Equals(Intensity, light.Intensity);
        }

        public override int GetHashCode()
        {
            var hashCode = 978863716;
            hashCode = hashCode * -1521134295 + EqualityComparer<Point>.Default.GetHashCode(Position);
            hashCode = hashCode * -1521134295 + EqualityComparer<RColor>.Default.GetHashCode(Intensity);
            return hashCode;
        }
    }
}
