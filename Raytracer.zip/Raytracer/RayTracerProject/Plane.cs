﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Plane : Shape
    {
        public override Intersections LocalIntersect(Ray ray)
        {
            Intersections result = new Intersections();
            if(Math.Abs(ray.Direction.Y) < 0.0001)
            {
                return result;
            }

            double time = -ray.Origin.Y / ray.Direction.Y;
            result.Add(new Intersection(time, this));

            return result;
        }

        public override RTuple LocalNormalAt(RTuple point)
        {
            return new Vector(0,1,0);
        }
    }
}
