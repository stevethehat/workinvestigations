﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Canvas
    {


        public int Width { get; }
        public int Height { get; }

        public RColor this[int x, int y]
        {
            get => pixels[x, y];
            set => pixels[x, y] = value;
        }

        private RColor[,] pixels;
        public Canvas(int width, int height)
        {
            Width = width;
            Height = height;
            Init();
        }


        private void Init()
        {
            pixels = new RColor[Width, Height];
            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    pixels[x, y] = new RColor(0, 0, 0);
                }
            }
        }

    }
}
