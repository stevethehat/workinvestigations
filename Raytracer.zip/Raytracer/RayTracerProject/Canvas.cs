﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Canvas
    {


        public int Width { get; }
        public int Height { get; }

        public RColor this[int x, int y]
        {
            get => pixels[x, y];
            set => pixels[x, y] = value;
        }

        private RColor[,] pixels;
        private int _centerX;
        private int _centerY;
        public Canvas(int width, int height)
        {
            Width = width;
            Height = height;
            _centerX = width / 2;
            _centerY = height / 2;
            Init();
        }

        public void DrawFromOrigin(int x, int y, RColor color)
        {
            this[_centerX + x, _centerY + y] = color;
        }

        private void Init()
        {
            pixels = new RColor[Width, Height];
            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    pixels[x, y] = new RColor(0, 0, 0);
                }
            }
        }

    }
}
