﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracerProject
{
    public class Material
    {
        public Material()
        {
            Color = new RColor(1, 1, 1);
            Ambient = 0.1;
            Diffuse = 0.9;
            Specular = 0.9;
            Shininess = 200;
        }

        public RColor Color { get; set; }
        public Pattern Pattern { get; set; }

        public double Ambient { get; set; }

        public double Diffuse { get; set; }

        public double Specular { get; set; }

        public double Shininess { get; set; }

        public RColor Lighting(Light light, Point position, Vector eye, Vector normal, bool inShadow = false)
        {
            var black = new RColor();
            RColor useColor;
            if (Pattern != null)
            {
                useColor = Pattern.ColorAt(position);
            } else
            {
                useColor = Color;
            }
            var effectiveColor = useColor * light.Intensity;
            var lightV = (light.Position - position).Normalize();

            var ambient = effectiveColor * Ambient;
            var diffuse = black;
            var specular = black;

            var lightDotNormal = lightV.Dot(normal);

            if(lightDotNormal >= 0)
            {
                diffuse = effectiveColor * Diffuse * lightDotNormal;

                var reflectv = (-lightV).Reflect(normal);
                var reflectDotEye = Math.Pow(reflectv.Dot(eye), Shininess);

                if(reflectDotEye > 0)
                {
                    specular = light.Intensity * Specular * reflectDotEye;
                }
            }

            if (inShadow)
            {
                return ambient;
            } else
            {
                return ambient + diffuse + specular;
            }
        }

        public override bool Equals(object obj)
        {
            var material = obj as Material;
            return material != null &&
                   EqualityComparer<RColor>.Default.Equals(Color, material.Color) &&
                   Ambient == material.Ambient &&
                   Diffuse == material.Diffuse &&
                   Specular == material.Specular &&
                   Shininess == material.Shininess;
        }

        public override int GetHashCode()
        {
            var hashCode = -1214519685;
            hashCode = hashCode * -1521134295 + EqualityComparer<RColor>.Default.GetHashCode(Color);
            hashCode = hashCode * -1521134295 + Ambient.GetHashCode();
            hashCode = hashCode * -1521134295 + Diffuse.GetHashCode();
            hashCode = hashCode * -1521134295 + Specular.GetHashCode();
            hashCode = hashCode * -1521134295 + Shininess.GetHashCode();
            return hashCode;
        }
    }
}
