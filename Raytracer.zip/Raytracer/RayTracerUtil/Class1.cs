﻿using System;

namespace RayTracerUtil
{
    public class Class1
    {
    }
}
