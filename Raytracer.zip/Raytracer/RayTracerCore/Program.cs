﻿using System;
using RayTracerProject;

namespace RayTracerCore
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix matrix = new Matrix(2,2);

            matrix[0,0] = 1;
            matrix[0,1] = 2;
            matrix[1,0] = 3;
            matrix[1,1] = 4;            
            
            Console.WriteLine("Raytracer");
            Console.WriteLine("=========");
            Console.WriteLine("");

            Console.Write(matrix.ToString());
            Console.WriteLine();
        }
    }
}
