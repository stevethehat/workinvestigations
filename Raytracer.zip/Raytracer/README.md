# The Ray Tracer Project (C#)

### Introduction

This project was setup for fun to create a ray tracer in C#. for this we used the book "The Ray Challege" by James Buck. You find this book [here] (https://pragprog.com/book/jbtracer/the-ray-tracer-challenge).

### Pre Requirements

You will need the following in order to build and write features:

- Visual Studio 2017
- VS Extentions:
    - Nunit3 Test Adapter 
    - SpecFlow for Visual Studio 2017
    
To install the extentions in Visual Studio go to Tools -> Extentions And Updates. Make sure you select "Online" and then search for the 2 extentions

### Contributors

* Mike Jones
* Steve Lamb
* Wayne Shakespear