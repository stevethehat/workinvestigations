﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests
{
    [Binding]
    public class CanvasSteps
    {
        [Given(@"(.*) ← canvas\((.*), (.*)\)")]
        public void GivenCCanvas(string name, int width, int height)
        {
            ScenarioContext.Current[name] = new Canvas(width,height);
        }
        
        [Then(@"(\w*)\.width = (.*)")]
        public void ThenC_Width(string name, int width)
        {
            var canvas = (Canvas)ScenarioContext.Current[name];
            Assert.That(canvas.Width, Is.EqualTo(width));
        }
        
        [Then(@"(\w*)\.height = (.*)")]
        public void ThenC_Height(string name, int height)
        {
            var canvas = (Canvas)ScenarioContext.Current[name];
            Assert.That(canvas.Height, Is.EqualTo(height));

        }

        [Then(@"every pixel of (\w*) is color\((.*), (.*), (.*)\)")]
        public void ThenEveryPixelOfCIsColor(string name, double r, double g, double b)
        {
            bool ok = true;
            Canvas c = (Canvas)ScenarioContext.Current[name];
            RColor expected = new RColor(r, g, b);
            for (int x = 0; x < c.Width; x++)
            {
                for (int y = 0; y < c.Height; y++)
                {
                    if(c[x, y] != expected)
                    {
                        ok = false;
                    }
                }
            }

            Assert.True(ok);
        }



        [When(@"write_pixel\((\w*), (.*), (.*), (\w*)\)")]
        public void WhenWrite_PixelCRed(string name, int x, int y, string colorName)
        {
            Canvas canvas = (Canvas)ScenarioContext.Current[name];
            RColor color = (RColor)ScenarioContext.Current[colorName];
            canvas[x, y] = color;
        }

        [Then(@"pixel_at\((\w*), (.*), (.*)\) = (\w*)")]
        public void ThenPixel_AtCRed(string name, int x, int y, string colorName)
        {
            Canvas canvas = (Canvas)ScenarioContext.Current[name];
            RColor color = (RColor)ScenarioContext.Current[colorName];

            Assert.That(canvas[x, y], Is.EqualTo(color));
        }

        [When(@"(\w*) ← canvas_to_ppm\((\w*)\)")]
        public void WhenPpmCanvas_To_PpmC(string ppmName, string canvasName)
        {
            Canvas canvas = (Canvas)ScenarioContext.Current[canvasName];
            ScenarioContext.Current[ppmName] = new PPMFile(canvas).Generate();
        }

        [Then(@"lines ([0-9]*)-([0-9]*) of (\w*) are")]
        public void ThenLinesOfPpmAre(int firstLine, int endLine, string ppmName, string multilineText)
        {
            string ppm = (string)ScenarioContext.Current[ppmName];
            string[] ppmLines = ppm.Split(new string[] { "\r" },StringSplitOptions.None);
            string[] multilineTextLines = multilineText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            bool ok = true;

            for(int i = firstLine -1; i < endLine; i++)
            {
                if(ppmLines[i] != multilineTextLines[i - firstLine + 1])
                {
                    ok = false;
                }
            }
            Assert.True(ok);
        }

        [When(@"every pixel of (\w*) is set to color\((.*), (.*), (.*)\)")]
        public void WhenEveryPixelOfCIsSetToColor(string name, double r, double g, double b)
        {
            Canvas c = (Canvas)ScenarioContext.Current[name];
            RColor color = new RColor(r, g, b);
            for (int x = 0; x < c.Width; x++)
            {
                for (int y = 0; y < c.Height; y++)
                {
                    c[x, y] = color;
                }
            }
        }

        [Then(@"the last character of (\w*) is a newline")]
        public void ThenTheLastCharacterOfPpmIsANewline(string ppmName)
        {
            string ppm = (string)ScenarioContext.Current[ppmName];
            string[] ppmLines = ppm.Split(new string[] { "\r" }, StringSplitOptions.None);
            Assert.IsEmpty(ppmLines[ppmLines.Length-1]);
        }


    }
}
