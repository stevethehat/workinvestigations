﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests.Steps
{
    [Binding]
    public class TransformationsSteps
    {
        [Given(@"(\w*) ← translation\((.*), (.*), (.*)\)")]
        public void GivenTransformTranslation(string translationName, double x, double y, double z)
        {
            ScenarioContext.Current[translationName] = Matrix.Translation(x, y, z);
        }
        
        [Then(@"(\w*) \* (\w*) = point\((-?\d*), (-?\d*), (-?\d*)\)")]
        public void ThenTransformPPoint(string matrixName, string pointName, double x, double y, double z)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Point point = (Point)ScenarioContext.Current[pointName];

            Point expected = new Point(x, y, z);


            Assert.That(matrix * point, Is.EqualTo(expected));
        }

        [Then(@"transform \* (\w*) = (\w*)")]
        public void ThenTransformVV(string vectorName, string _notNeeded)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current["transform"];
            Vector vector = (Vector)ScenarioContext.Current[vectorName];

            Assert.That(matrix * vector, Is.EqualTo(vector));
        }

        [Given(@"(\w*) ← scaling\((.*), (.*), (.*)\)")]
        public void GivenTransformScaling(string matrixName, double x, double y, double z)
        {
            ScenarioContext.Current[matrixName] = Matrix.Scale(x, y, z);
        }

        [Then(@"(\w*) \* (\w*) = vector\((.*), (.*), (.*)\)")]
        public void ThenTransformVVector(string matrixName, string vectorName, double x, double y, double z)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Vector vector = (Vector)ScenarioContext.Current[vectorName];

            Vector expected = new Vector(x, y, z);


            Assert.That(matrix * vector, Is.EqualTo(expected));
        }

        [Given(@"(\w*) ← rotation_x\(π / (.*)\)")]
        public void GivenHalf_QuarterRotation_X(string matrixName, double rotation)
        {
            ScenarioContext.Current[matrixName] = Matrix.RotateX(Math.PI / rotation);
        }

        [Given(@"(\w*) ← rotation_y\(π / (.*)\)")]
        public void GivenHalf_QuarterRotation_Y(string matrixName, double rotation)
        {
            ScenarioContext.Current[matrixName] = Matrix.RotateY(Math.PI / rotation);
        }

        [Given(@"(\w*) ← rotation_z\(π / (.*)\)")]
        public void GivenHalf_QuarterRotation_Z(string matrixName, double rotation)
        {
            ScenarioContext.Current[matrixName] = Matrix.RotateZ(Math.PI / rotation);
        }

        [Then(@"(\w*) \* (\w*) = point\((-?\d*), √(-?\d*)\/(-?\d*), √(-?\d*)\/(-?\d*)\)")]
        public void TestingXRotation(string matrixName, string pointName, double x, double y1, double y2, double z1, double z2)
        {
            Matrix matrix =  (Matrix)ScenarioContext.Current[matrixName];
            Point point = (Point)ScenarioContext.Current[pointName];



            Point expected = new Point(x, Math.Sqrt(y1) / y2, Math.Sqrt(z1) / z2);

            Assert.That(matrix * point, Is.EqualTo(expected));
        
        }

        [Then(@"(\w*) \* (\w*) = point\((-?\d*), √(-?\d*)\/(-?\d*), -√(-?\d*)\/(-?\d*)\)")]
        public void ThenHalf_QuarterPPoint2(string matrixName, string pointName, double x, double y1, double y2, double z1, double z2)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Point point = (Point)ScenarioContext.Current[pointName];



            Point expected = new Point(x, Math.Sqrt(y1) / y2, (Math.Sqrt(z1) / z2) * -1);

            Assert.That(matrix * point, Is.EqualTo(expected));

        }

        [Then(@"(\w*) \* (\w*) = point\(√(-?\d*)\/(-?\d*), (-?\d*), √(-?\d*)\/(-?\d*)\)")]
        public void TestingYRotation(string matrixName, string pointName, double x1, double x2, double y, double z1, double z2)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Point point = (Point)ScenarioContext.Current[pointName];



            Point expected = new Point(Math.Sqrt(x1) / x2, y, Math.Sqrt(z1) / z2);

            Assert.That(matrix * point, Is.EqualTo(expected));

        }


        [Then(@"(\w*) \* (\w*) = point\(-√(-?\d*)\/(-?\d*), √(-?\d*)\/(-?\d*), (-?\d*)\)")]
        public void TestingZRotation(string matrixName, string pointName, double x1, double x2, double y1, double y2, double z)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Point point = (Point)ScenarioContext.Current[pointName];



            Point expected = new Point((Math.Sqrt(x1) / x2) * -1, Math.Sqrt(y1) / y2, z);

            Assert.That(matrix * point, Is.EqualTo(expected));

        }

        [Given(@"(\w*) ← shearing\((.*), (.*), (.*), (.*), (.*), (.*)\)")]
        public void GivenTransformShearing(string name, double xY, double xZ, double yX, double yZ, double zX, double zY)
        {
            ScenarioContext.Current[name] = Matrix.Shear(xY, xZ, yX, yZ, zX, zY);
        }

        [When(@"(\w*) ← (\w*) \* (\w*)")]
        public void WhenPBP(string tupleName, string matrixName, string pointName)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            RTuple point = (RTuple)ScenarioContext.Current[pointName];

            ScenarioContext.Current[tupleName] = matrix * point;
        }

        [Then(@"(\w*) = point\((.*), (.*), (.*)\)")]
        public void ThenPPoint(string tupleName, double x, double y, double z)
        {
            RTuple point = (RTuple)ScenarioContext.Current[tupleName];

            Point expected = new Point(x, y, z);
            Assert.That(point, Is.EqualTo(expected));

        }

        [When(@"(\w*) ← (\w*) \* (\w*) \* (\w*)")]
        public void WhenTCBA(string returnTupleName,string matrix1Name, string matrix2Name, string matrix3Name)
        {
            Matrix matrix1 = (Matrix)ScenarioContext.Current[matrix1Name];
            Matrix matrix2 = (Matrix)ScenarioContext.Current[matrix2Name];
            Matrix matrix3 = (Matrix)ScenarioContext.Current[matrix3Name];

            Matrix result = matrix1 * (matrix2 * matrix3);

            ScenarioContext.Current[returnTupleName] = result;
        }



    }
}
