﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests.Steps
{
    [Binding]
    public class ThenSteps
    {
        [Then(@"(\w*)\.origin = (\w*)")]
        public void ThenR_OriginOrigin(string rayName, string pointName)
        {
            var ray = (Ray)ScenarioContext.Current[rayName];
            var point = (Point)ScenarioContext.Current[pointName];

            Assert.That(ray.Origin, Is.EqualTo(point));

        }

        [Then(@"(\w*)\.direction = (\w*)")]
        public void ThenR_DirectionDirection(string rayName, string vectorName)
        {
            var ray = (Ray)ScenarioContext.Current[rayName];
            var vector = (Vector)ScenarioContext.Current[vectorName];

            Assert.That(ray.Direction, Is.EqualTo(vector));
        }

        [Then(@"position\((\w*), (.*)\) = point\((.*), (.*), (.*)\)")]
        public void ThenPositionRPoint(string rayName, double position, double x, double y, double z)
        {
            var ray = (Ray)ScenarioContext.Current[rayName];
            var expected = new Point(x, y, z);
            Assert.That(ray.Position(position), Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.count = (.*)")]
        public void ThenXs_Count(string intersectionName, int count)
        {
            var intersetion = (IList)ScenarioContext.Current[intersectionName];

            Assert.That(intersetion.Count, Is.EqualTo(count));
        }

        [Then(@"(\w*)\[(.*)] = (.*)")]
        public void ThenXs(string intersectionName, int position, double value)
        {
            var intersetion = (Intersections)ScenarioContext.Current[intersectionName];

            Assert.That(intersetion[position].Time, Is.EqualTo(value));
        }

        [Then(@"(\w*)\.t = (.*)")]
        public void ThenI_T(string intersectionName, double time)
        {
            var intersection = (Intersection)ScenarioContext.Current[intersectionName];

            Assert.That(intersection.Time, Is.EqualTo(time));
        }

        [Then(@"(\w*)\.object = (\w*)")]
        public void ThenI_ObjectS(string intersectionName, string sphereName)
        {
            var intersection = (Intersection)ScenarioContext.Current[intersectionName];
            var sphere = (Sphere)ScenarioContext.Current[sphereName];

            Assert.That(intersection.Shape, Is.EqualTo(sphere));
        }

        [Then(@"(\w*)\[(\d*)]\.t = (\d*?.\d*)")]
        public void ThenXs_T(string intersectionsName, int index, double time)
        {
            var intersections = (Intersections)ScenarioContext.Current[intersectionsName];

            Assert.That(intersections[index].Time, Is.EqualTo(time));
        }

        [Then(@"(\w*)\[(\d*)]\.object = (\w*)")]
        public void ThenXs_Object(string intersectionsName, int index, string objectName)
        {
            var shape = (Sphere)ScenarioContext.Current[objectName];
            var intersections = (Intersections)ScenarioContext.Current[intersectionsName];

            Assert.That(intersections[index].Shape, Is.EqualTo(shape));
        }

        [Then(@"(\w*) = (\w*\d+)")]
        public void ThenHI(string hitName, string intersectionName)
        {
            var hit = (Intersection)ScenarioContext.Current[hitName];
            var intersection = (Intersection)ScenarioContext.Current[intersectionName];

            Assert.That(hit, Is.EqualTo(intersection));
        }

        [Then(@"(\w*) is nothing")]
        public void ThenNullHI(string hitName)
        {
            var hit = (Intersection)ScenarioContext.Current[hitName];

            Assert.That(hit, Is.Null);
        }

        [Then(@"(\w*)\.origin = point\((.*), (.*), (.*)\)")]
        public void ThenR_OriginPoint(string rayName, double x, double y, double z)
        {
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Point expected = new Point(x, y, z);

            Assert.That(ray.Origin, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.direction = vector\((-?\d*?.\d*), (-?\d*?.\d*), (-?\d*?.\d*)\)")]
        public void ThenR_DirectionVector(string rayName, double x, double y, double z)
        {
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Vector expected = new Vector(x, y, z);

            Assert.That(ray.Direction, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.direction = vector\(√(\d*)\/(\d*), (\d*), -√(\d*)\/(\d*)\)")]
        public void ThenR_DirectionVector(string rayName, double x1, double x2, double y, double z1, double z2)
        {
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Vector expected = new Vector(Math.Sqrt(x1) / x2, y, -Math.Sqrt(z1) / z2);

            Assert.That(ray.Direction, Is.EqualTo(expected));
        }


        [Then(@"(\w*)\.transform = (\w*)")]
        public void ThenS_TransformT(string sphereName, string matrixName)
        {
            var transformObeject = ScenarioContext.Current[sphereName];
            
            Matrix matrix = matrixName == "identity_matrix" ?
                Matrix.Identity() :
                (Matrix)ScenarioContext.Current[matrixName];

            switch (transformObeject)
            {
                case Sphere s:
                    Assert.That(s.Transform, Is.EqualTo(matrix));
                    break;
                case Camera c:
                    Assert.That(c.Transform, Is.EqualTo(matrix));
                    break;
                default:
                    Assert.True(false, "Object is not a sphere or camera");
                    break;
            }

            
        }

        [Then(@"(\w*) = vector\((.*), (.*), (.*)\)")]
        public void ThenNVector(string normalName, double x, double y, double z)
        {
            var normal = (Vector)ScenarioContext.Current[normalName];
            var expected = new Vector(x, y, z);

            Assert.That(normal, Is.EqualTo(expected));
        }

        [Then(@"(\w*) = vector\(√(\d*)\/(\d*), √(\d*)\/(\d*), √(\d*)\/(\d*)\)")]
        public void ThenNVector(string normalName, double x1, double x2,  double y1, double y2, double z1, double z2)
        {
            var normal = (Vector)ScenarioContext.Current[normalName];

            var expected = new Vector(Math.Sqrt(x1) / x2, Math.Sqrt(y1) / y2, Math.Sqrt(z1) / z2);

            Assert.That(normal, Is.EqualTo(expected));
        }

        [Then(@"(\w*) = normalize\((\w*)\)")]
        public void ThenNNormalizeN(string normalName1, string normalName2)
        {
            var normal1 = (Vector)ScenarioContext.Current[normalName1];
            var normal2 = (Vector)ScenarioContext.Current[normalName2];

            Assert.That(normal1, Is.EqualTo(normal2.Normalize()));
        }

        [Then(@"(\w*) ← normal_at\((\w*), point\(√(\d*)\/(\d*), √(\d*)\/(\d*), √(\d*)\/(\d*)\)\)")]
        public void ThenNNormal_AtSPoint2(string normalName, string sphereName, double x1, double x2, double y1, double y2, double z1, double z2)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var point = new Point(Math.Sqrt(x1) / x2, Math.Sqrt(y1) / y2, Math.Sqrt(z1) / z2);

            ScenarioContext.Current[normalName] = sphere.NormalAt(point);
        }

        [Then(@"(\w*)\.position = (\w*)")]
        public void ThenLight_PositionPosition(string lightName, string positionName)
        {
            var light = (PointLight)ScenarioContext.Current[lightName];
            var position = (Point)ScenarioContext.Current[positionName];

            Assert.That(light.Position, Is.EqualTo(position));
        }

        [Then(@"(\w*)\.intensity = (\w*)")]
        public void ThenLight_IntensityIntensity(string lightName, string colourName)
        {
            var light = (PointLight)ScenarioContext.Current[lightName];
            var colour = (RColor)ScenarioContext.Current[colourName];

            Assert.That(light.Intensity, Is.EqualTo(colour));
        }

        [Then(@"(\w*)\.color = color\((.*), (.*), (.*)\)")]
        public void ThenM_ColorColor(string materialName, double r, double g, double b)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            var expected = new RColor(r, g, b);

            Assert.That(material.Color, Is.EqualTo(expected));

        }

        [Then(@"(\w*)\.ambient = (.*)")]
        public void ThenM_Ambient(string materialName, double expected)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            Assert.That(material.Ambient, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.diffuse = (.*)")]
        public void ThenM_Diffuse(string materialName, double expected)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            Assert.That(material.Diffuse, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.specular = (.*)")]
        public void ThenM_Specular(string materialName, double expected)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            Assert.That(material.Specular, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.shininess = (.*)")]
        public void ThenM_Shininess(string materialName, double expected)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            Assert.That(material.Shininess, Is.EqualTo(expected));
        }

        [Then(@"(\w*) = material\(\)")]
        public void ThenMMaterial(string materialName)
        {
            var material = (Material)ScenarioContext.Current[materialName];

            var expected = new Material();

            Assert.That(material, Is.EqualTo(expected));

        }

        [Then(@"(\w*)\.material = (\w*)")]
        public void ThenS_MaterialM(string sphereName, string materialName)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var material = (Material)ScenarioContext.Current[materialName];

            Assert.That(sphere.Material, Is.EqualTo(material));

        }

        [Then(@"(\w*) = color\((.*), (.*), (.*)\)")]
        public void ThenResultColor(string colorName, double r, double g, double b)
        {
            var colour = (RColor)ScenarioContext.Current[colorName];
            var expected = new RColor(r, g, b);

            Assert.That(colour, Is.EqualTo(expected));
        }


        [Then(@"(\w*) contains no objects")]
        public void ThenWContainsNoObjects(string worldName)
        {
            var world = (World)ScenarioContext.Current[worldName];

            Assert.That(world.Objects.Count, Is.EqualTo(0));
        }

        [Then(@"(\w*) has no light source")]
        public void ThenWHasNoLightSource(string worldName)
        {
            var world = (World)ScenarioContext.Current[worldName];

            Assert.That(world.Lights.Count, Is.EqualTo(0));
        }

        [Then(@"(\w*)\.light = (\w*)")]
        public void ThenWorld_LightLight(string worldName, string lightName)
        {
            var world = (World)ScenarioContext.Current[worldName];
            var light = (PointLight)ScenarioContext.Current[lightName];
            Assert.That(world.Lights[0], Is.EqualTo(light));
        }

        [Then(@"(\w*) contains (\w*)")]
        public void ThenWorldContainsS(string worldName, string objectName)
        {
            var world = (World)ScenarioContext.Current[worldName];
            var sphere = (Sphere)ScenarioContext.Current[objectName];
            bool result = false;
            foreach(var s in world.Objects)
            {
                if(s.Equals(sphere))
                {
                    result = true;
                    break;
                }
            }

            Assert.True(result);
        }

        [Then(@"(\w*)\.point = point\((.*), (.*), (.*)\)")]
        public void ThenHit_PointPoint(string intersectionName, double x, double y, double z)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Point expected = new Point(x, y, z);

            Assert.That(intersection.Point, Is.EqualTo(expected));
        }

        [Then(@"(\w*)\.eyev = vector\((.*), (.*), (.*)\)")]
        public void ThenHit_EyevVector(string intersectionName, double x, double y, double z)
        {
            Intersection intersection  = (Intersection)ScenarioContext.Current[intersectionName];
            Vector expected = new Vector(x, y, z);

            Assert.That(intersection.Eye, Is.EqualTo(expected));

        }

        [Then(@"(\w*)\.normalv = vector\((.*), (.*), (.*)\)")]
        public void ThenHit_NormalvVector(string intersectionName, double x, double y, double z)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Vector expected = new Vector(x, y, z);

            Assert.That(intersection.Normal, Is.EqualTo(expected));

        }

        [Then(@"(\w*)\.inside = false")]
        public void ThenHit_InsideFalse(string intersectionName)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Assert.False(intersection.Inside);
        }

        [Then(@"(\w*)\.inside = true")]
        public void ThenHit_InsideTrue(string intersectionName)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Assert.True(intersection.Inside);
        }

        [Then(@"(\w*) = (\w*)\.material\.color")]
        public void ThenCInner_Material_Color(string colorName, string objectName)
        {
            Sphere obj = (Sphere)ScenarioContext.Current[objectName];
            ScenarioContext.Current[colorName] = obj.Material.Color;
        }

        [Then(@"(\w*) = scaling\((.*), (.*), (.*)\)")]
        public void ThenTScaling(string matrixName, double x, double y, double z)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            Matrix expected = Matrix.Scale(x, y, z);

            Assert.That(matrix, Is.EqualTo(expected));
        }

        [Then(@"(\w*) = translation\((.*), (.*), (.*)\)")]
        public void ThenTTranslation(string matrixName, double x, double y, double z)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            Matrix expected = Matrix.Translation(x, y, z);

            Assert.That(matrix, Is.EqualTo(expected));
        }


        [Then(@"(\w*)\.hsize = (.*)")]
        public void ThenC_Hsize(string cameraName, double value)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];

            Assert.That(camera.HSize, Is.EqualTo(value));

        }

        [Then(@"(\w*)\.vsize = (.*)")]
        public void ThenC_Vsize(string cameraName, double value)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];

            Assert.That(camera.VSize, Is.EqualTo(value));
        }

        [Then(@"(\w*)\.field_of_view = π/(.*)")]
        public void ThenC_Field_Of_ViewΠ(string cameraName, double value)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];

            Assert.That(camera.FieldOfView, Is.EqualTo(Math.PI / value));
        }

        [Then(@"(\w*)\.pixel_size = (.*)")]
        public void ThenC_Pixel_Size(string cameraName, double pixelSize)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];

            Assert.That(camera.PixelSize, Is.EqualTo(pixelSize).Within(0.0001));
        }

        [Then(@"pixel_at\((\w*), (.*), (.*)\) = color\((.*), (.*), (.*)\)")]
        public void ThenPixel_AtImageColor(string canvasName, int x, int y, double r, double g, double b)
        {
            Canvas canvas = (Canvas)ScenarioContext.Current[canvasName];

            RColor expected = new RColor(r, g, b);

            Assert.That(canvas[x, y], Is.EqualTo(expected));
        }



    }
}
