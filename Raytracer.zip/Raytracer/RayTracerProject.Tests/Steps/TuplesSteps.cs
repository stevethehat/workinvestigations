﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests.Steps
{
    [Binding]
    public class TuplesSteps
    {
        
        [Given(@"(.*) ← tuple\((.*), (.*), (.*), (.*)\)")]
        public void GivenATuple(string name, double x, double y, double z, double w)
        {
            ScenarioContext.Current[name] = new RTuple(x, y, z, w);
        }

        [Given(@"(\w*) ← point\((-?\d*), (-?\d*), (-?\d*)\)")]
        public void GivenPPoint(string name, double x, double y, double z)
        {
            ScenarioContext.Current[name] = RTuple.Point(x, y, z);

        }
     

        [Then(@"(.*)\.x = (.*)")]
        public void ThenA_X(string name, double xVal)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.X, Is.EqualTo(xVal));
        }
        
        [Then(@"(.*)\.y = (.*)")]
        public void ThenA_Y(string name, double yVal)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.Y, Is.EqualTo(yVal));
        }

        [Then(@"(.*)\.z = (.*)")]
        public void ThenA_Z(string name, double zVal)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.Z, Is.EqualTo(zVal));
        }
        
        [Then(@"(.*)\.w = (.*)")]
        public void ThenA_W(string name, double wVal)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.W, Is.EqualTo(wVal));
        }
        
        [Then(@"(.*) is a point")]
        public void ThenAIsAPoint(string name)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.IsPoint(), Is.True);

        }

        [Then(@"(.*) is not a vector")]
        public void ThenANotIsAVector(string name)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.IsVector(), Is.False);

        }


        [Then(@"(.*) is not a point")]
        public void ThenAIsNotAPoint(string name)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.IsPoint(), Is.False);
        }

        [Then(@"(.*) is a vector")]
        public void ThenAIsAVector(string name)
        {
            var tuple = (RTuple)ScenarioContext.Current[name];
            Assert.That(tuple.IsVector(), Is.True);

        }

        [Then(@"(.\w*) \+ (.\w*) = tuple\((.*), (.*), (.*), (.*)\)")]
        public void ThenAddTuple(string name1, string name2, double x, double y, double z, double w)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name1];
            var tuple2 = (RTuple)ScenarioContext.Current[name2];
            var tuple3 = new RTuple(x, y, z, w);

            Assert.That(tuple1 + tuple2, Is.EqualTo(tuple3));
        }

        [Then(@"(.\w*) - (.\w*) = vector\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)")]
        public void ThenSubtractVector(string name1, string name2, double x, double y, double z)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name1];
            var tuple2 = (RTuple)ScenarioContext.Current[name2];
            var tuple3 = RTuple.Vector(x, y, z);

            Assert.That(tuple1 - tuple2, Is.EqualTo(tuple3));
        }

        [Then(@"([^-]\w*) = tuple\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)")]
        public void ThenTupleEqualsTuple(string name, double x, double y, double z, double w)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name];
            var tuple2 = new RTuple(x, y, z, w);

            Assert.That(tuple1 == tuple2, Is.True);

        }

        [Then(@"-(\w*) = tuple\((.*), (.*), (.*), (.*)\)")]
        public void ThenMinusTupleEqualsMinusTuple(string name, double x, double y, double z, double w)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name];
            var tuple2 = new RTuple(x, y, z, w);
            Assert.That(-tuple1 == tuple2, Is.True);

        }

        [Then(@"(\w*) \* ([0-9]*.[0-9]*) = tuple\((.*), (.*), (.*), (.*)\)")]
        public void ThenRTupleMultiplier(string name, double multipler, double x, double y, double z, double w)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name];
            var tuple2 = new RTuple(x, y, z, w);

            Assert.That(tuple1 * multipler == tuple2, Is.True);
        }

        [Then(@"(\w*) / (.*) = tuple\((.*), (.*), (.*), (.*)\)")]
        public void ThenRTupleDivider(string name, double divider, double x, double y, double z, double w)
        {
            var tuple1 = (RTuple)ScenarioContext.Current[name];
            var tuple2 = new RTuple(x, y, z, w);

            Assert.That(tuple1 / divider == tuple2, Is.True);
        }


        [Then(@"magnitude\((\w*)\) = (\d*)")]
        public void ThenMagnitudeV(string name, double magnitude)
        {
            var v = (RTuple)ScenarioContext.Current[name];
            Assert.That(v.Magnitude(), Is.EqualTo(magnitude));
        }

        [Then(@"magnitude\((\w*)\) = √(\d*)")]
        public void ThenMagnitudeSqurt(string name, double magnitude)
        {
            var v = (RTuple)ScenarioContext.Current[name];
            Assert.That(v.Magnitude(), Is.EqualTo(Math.Sqrt(magnitude)));
        }


        [Then(@"normalize\((\w*)\) = vector\((.*), (.*), (.*)\)")]
        public void ThenNormalizeVVector(string name, double x, double y, double z)
        {
            var v = (RTuple)ScenarioContext.Current[name];
            var expected = new RTuple(x, y, z, 0f);
            Assert.That(v.Normalize(), Is.EqualTo(expected));
        }

        [Then(@"normalize\((\w*)\) = approximately vector\((.*), (.*), (.*)\)")]
        public void ThenNormalizeVApproximatelyVector(string name, double x, double y, double z)
        {
            var v = (RTuple)ScenarioContext.Current[name];
            var expected = new RTuple(x, y, z, 0f);
            Assert.That(v.Normalize(), Is.EqualTo(expected));
        }

        [When(@"(\w*) ← normalize\((\w*)\)")]
        public void WhenNormNormalizeV(string normName, string name)
        {
            var v = (RTuple)ScenarioContext.Current[name];
            ScenarioContext.Current[normName] = v.Normalize();
        }

        [Then(@"dot\((\w*), (\w*)\) = (.*)")]
        public void ThenDotAB(string vName1, string vName2, double dotValue)
        {
            var v1 = (RTuple)ScenarioContext.Current[vName1];
            var v2 = (RTuple)ScenarioContext.Current[vName2];

            Assert.That(v1.Dot(v2), Is.EqualTo(dotValue));

        }

        [Then(@"cross\((\w*), (\w*)\) = vector\((.*), (.*), (.*)\)")]
        public void ThenCrossVector(string vName1, string vName2, double x, double y, double z)
        {
            var v1 = (RTuple)ScenarioContext.Current[vName1];
            var v2 = (RTuple)ScenarioContext.Current[vName2];
            var v3 = RTuple.Vector(x, y, x);

            Assert.That(v1.Cross(v2), Is.EqualTo(v3));
        }

        [Given(@"(.*) ← color\((.*), (.*), (.*)\)")]
        public void GivenCColor(string name, double r, double g, double b)
        {
            var color = new RColor(r, g, b);
            ScenarioContext.Current[name] = color;
        }

        [Then(@"(\w*)\.red = (.*)")]
        public void ThenC_Red(string name, double r)
        {
            var color = (RColor)ScenarioContext.Current[name];
            Assert.That(color.R, Is.EqualTo(r));
        }

        [Then(@"(\w*)\.green = (.*)")]
        public void ThenC_Green(string name, double g)
        {
            var color = (RColor)ScenarioContext.Current[name];
            Assert.That(color.G, Is.EqualTo(g));
        }

        [Then(@"(\w*)\.blue = (.*)")]
        public void ThenC_Blue(string name, double b)
        {
            var color = (RColor)ScenarioContext.Current[name];
            Assert.That(color.B, Is.EqualTo(b));
        }

        [Then(@"(\w*) \+ (\w*) = color\((.*), (.*), (.*)\)")]
        public void ThenCCColor(string col1, string col2, double r, double g, double b)
        {
            var color1 = (RColor)ScenarioContext.Current[col1];
            var color2 = (RColor)ScenarioContext.Current[col2];

            var expected = new RColor(r, g, b);
            Assert.That(color1 + color2, Is.EqualTo(expected));
        }

        [Then(@"(\w*) - (\w*) = color\((.*), (.*), (.*)\)")]
        public void ThenC_CColor(string col1, string col2, double r, double g, double b)
        {
            var color1 = (RColor)ScenarioContext.Current[col1];
            var color2 = (RColor)ScenarioContext.Current[col2];

            var expected = new RColor(r, g, b);
            Assert.That(color1 - color2, Is.EqualTo(expected));
        }

        [Then(@"(\w*) \* ([0-9]*) = color\((.*), (.*), (.*)\)")]
        public void ThenCColor(string col, double timesBy, double r, double g, double b)
        {
            var color = (RColor)ScenarioContext.Current[col];
            var expected = new RColor(r, g, b);

            Assert.That(color * timesBy, Is.EqualTo(expected));
        }


        [Then(@"([a-z][0-9]) \* ([a-z][0-9]) = color\((.*), (.*), (.*)\)")]
        public void ThenMultipleColors(string col1, string col2, double r, double g, double b)
        {
            var color1 = (RColor)ScenarioContext.Current[col1];
            var color2 = (RColor)ScenarioContext.Current[col2];

            var expected = new RColor(r, g, b);
            Assert.That(color1 * color2, Is.EqualTo(expected));
        }

    }
}
