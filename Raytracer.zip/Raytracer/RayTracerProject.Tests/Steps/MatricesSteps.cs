﻿using System;
using System.Linq;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests.Steps
{
    [Binding]
    public class MatricesSteps
    {
        protected Matrix PopulateMatrix(int width, int height, Table table)
        {
            Matrix result = new Matrix(width, height);

            var header = table.Header.ToArray();
            for (int y = 0; y < header.Length; y++)
            {
                result[0, y] = Convert.ToDouble(header[y]);
            }
            

            for (int x = 0; x < table.RowCount; x++)
            {
                TableRow row = table.Rows[x];
                for (int y = 0; y < row.Count; y++)
                {
                    result[x+1, y] = Convert.ToDouble(row[y]);
                }
            }

            return result;
        }
        [Given(@"the following ([0-9]*)x([0-9]*) matrix (\w*):")]
        public void GivenTheFollowingMatrixM(int width, int height, string name, Table table)
        {
            ScenarioContext.Current[name] = PopulateMatrix(width, height, table);
        }
        
        [Then(@"(\w*)\[(\d*),(\d*)] = (-?\d*\.?\d*)")]
        public void ThenM(string name, int x, int y, double result)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[name];
            Assert.That(matrix[x, y], Is.EqualTo(result));
        }

        [Given(@"the following matrix (\w*):")]
        public void GivenTheFollowingMatrixA(string name,Table table)
        {
            ScenarioContext.Current[name] = PopulateMatrix(table.RowCount + 1, table.Rows[0].Count, table);
        }


        [Then(@"(\w*) \* (\w*) is the following ([0-9]*)x([0-9]*) matrix:")]
        public void ThenABIsTheFollowingMatrix(string name1, string name2, int rows, int columns, Table table)
        {
            Matrix matrix1 = (Matrix)ScenarioContext.Current[name1];
            Matrix matrix2 = (Matrix)ScenarioContext.Current[name2];
            Matrix expected = PopulateMatrix(rows, columns, table);

            var result = matrix1 * matrix2;
            Assert.That(result, Is.EqualTo(expected));
        }

        [Then(@"(\w*) \* (\w*) = tuple\((.*), (.*), (.*), (.*)\)")]
        public void ThenABTuple(string matrixName, string tupleName, double x, double y, double z, double w)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            RTuple tuple = (RTuple)ScenarioContext.Current[tupleName];

            RTuple expected = new RTuple(x, y, z, w);
            var result = matrix * tuple;
            Assert.That(result, Is.EqualTo(expected));


        }

        [Then(@"(\w*) \* identity_matrix = (\w*)")]
        public void ThenAIdentity_MatrixA(string matrixName, string _matrixNameAgain)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Assert.That(matrix * Matrix.Identity(), Is.EqualTo(matrix));
        }

        [Then(@"identity_matrix \* (\w*) = (\w*)")]
        public void ThenIdentity_MatrixAA(string tupleName, string tupleNameAgain)
        {
            RTuple tuple = (RTuple)ScenarioContext.Current[tupleName];
            Assert.That(Matrix.Identity() * tuple, Is.EqualTo(tuple));
        }

        [Then(@"transpose\((\w*)\) is the following matrix:")]
        public void ThenTransposeAIsTheFollowingMatrix(string matrixName, Table table)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Matrix expected = PopulateMatrix(table.RowCount + 1, table.Rows[0].Count, table);

            Assert.That(expected, Is.EqualTo(matrix.Transpose()));
        }


        [Given(@"(\w*) ← transpose\(identity_matrix\)")]
        public void GivenATransposeIdentity_Matrix(string matixName)
        {
            ScenarioContext.Current[matixName] = Matrix.Identity().Transpose();
        }

        [Then(@"(\w*) = identity_matrix")]
        public void ThenAIdentity_Matrix(string matrixName)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Assert.That(Matrix.Identity(), Is.EqualTo(matrix));

        }

        [Then(@"determinant\((\w*)\) = (.*)")]
        public void ThenDeterminantA(string matrixName, double expected)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Assert.That(matrix.Determinant(), Is.EqualTo(expected));

        }


        [Then(@"submatrix\((\w*), (.*), (.*)\) is the following ([0-9]*)x([0-9]*) matrix:")]
        public void ThenSubmatrixAIsTheFollowingMatrix(string matrixName, int row, int col, int newMatrixWidth, int newMatrixHeight, Table table)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Matrix expected = PopulateMatrix(newMatrixWidth, newMatrixHeight, table);

            Assert.That(expected, Is.EqualTo(matrix.SubMatrix(row,col)));

        }

        [Given(@"(\w*) ← submatrix\((\w*), (.*), (.*)\)")]
        public void GivenBSubmatrixA(string subMatrixName, string matrixName, int row, int column)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            ScenarioContext.Current[subMatrixName] = matrix.SubMatrix(row,column);
        }

        [Then(@"minor\((\w*), (.*), (.*)\) = (.*)")]
        public void ThenMinorA(string matrixName, int row, int col, double expected)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            Assert.That(expected, Is.EqualTo(matrix.Minor(row, col)));

        }

        [Then(@"cofactor\((\w*), (.*), (.*)\) = (.*)")]
        public void ThenMA(string matrixName, int row, int col, double expected)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            Assert.That(matrix.Cofactor(row, col), Is.EqualTo(expected));
        }

        [Then(@"(\w*) is invertible")]
        public void ThenAIsInvertible(string matrixName)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Assert.True(matrix.IsInvertable);

        }

        [Then(@"(\w*) is not invertible")]
        public void ThenAIsNotInvertible(string matrixName)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Assert.False(matrix.IsInvertable);

        }

        [Given(@"(\w*) ← inverse\((\w*)\)")]
        public void GivenBInverseA(string investionName, string matrixName)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            ScenarioContext.Current[investionName] = matrix.Invert();
        }

        [Then(@"(\w*) is the following ([0-9]*)x([0-9]*) matrix:")]
        public void ThenBIsTheFollowingMatrix(string matrixName, int rows, int cols, Table table)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            Matrix expected = PopulateMatrix(rows, cols, table);

            Assert.That(matrix, Is.EqualTo(expected));

        }

        [Then(@"(\w*)\[(\d*),(\d*)] = (-?\d*)\/(-?\d*)")]
        public void ThenB(string matrixName, int row, int col, double value1, double value2)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            var result = matrix[row, col];
            double expected = value1 / value2;

            Assert.That(result, Is.EqualTo(expected));
        }

        [Then(@"inverse\((\w*)\) is the following ([0-9]*)x([0-9]*) matrix:")]
        public void ThenInverseAIsTheFollowingMatrix(string matrixName, int width, int height, Table table)
        {
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            Matrix expected = PopulateMatrix(width, height, table);

            Assert.That(matrix.Invert(), Is.EqualTo(expected));

        }


        [Given(@"(\w*) ← (\w*) \* (\w*)")]
        public void GivenCAB(string matrixNameA, string matrixNameB, string matrixNameC)
        {
            Matrix matrixB = (Matrix)ScenarioContext.Current[matrixNameB];
            Matrix matrixC = (Matrix)ScenarioContext.Current[matrixNameC];
            ScenarioContext.Current[matrixNameA] = matrixB * matrixC;
        }

        [Then(@"(\w*) \* inverse\((\w*)\) = (\w*)")]
        public void ThenCInverseBA(string matrixNameA, string matrixNameB, string matrixNameC)
        {
            Matrix matrixA = (Matrix)ScenarioContext.Current[matrixNameA];
            Matrix matrixB = (Matrix)ScenarioContext.Current[matrixNameB];
            Matrix matrixC = (Matrix)ScenarioContext.Current[matrixNameC];

            Assert.That(matrixA * matrixB.Invert(), Is.EqualTo(matrixC));
        }









    }
}
