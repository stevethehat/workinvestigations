﻿using System;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests
{
    [Binding]
    public class WhenSteps
    {
        [When(@"(\w*) ← ray\((\w*), (\w*)\)")]
        public void WhenRRayOriginDirection(string rayName, string pointName,string vectorName )
        {
            var point = (Point)ScenarioContext.Current[pointName];
            var vector = (Vector)ScenarioContext.Current[vectorName];

            ScenarioContext.Current[rayName] = new Ray(point, vector);
        }


        [When(@"(\w*) ← intersect\((\w*), (\w*)\)")]
        public void WhenXsIntersectSR(string intersectionName, string shapeName, string rayName)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            var ray = (Ray)ScenarioContext.Current[rayName];


            ScenarioContext.Current[intersectionName] = shape.Intersect(ray);
        }

        [When(@"(\w*) ← intersection\((.*), (\w*)\)")]
        public void WhenIIntersectionS(string intersectionName, double time, string shapeName)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[intersectionName] = new Intersection(time, shape);
        }
        [When(@"(\w*) ← intersections\((\w*), (\w*)\)")]
        public void WhenXsIntersectionsII(string intersectionsName, string intersection1Name, string intersection2Name)
        {
            Intersection intersection1 = (Intersection)ScenarioContext.Current[intersection1Name];
            Intersection intersection2 = (Intersection)ScenarioContext.Current[intersection2Name];

            Intersections intersections = new Intersections();
            intersections.Add(intersection1);
            intersections.Add(intersection2);

            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [When(@"(\w*) ← hit\((\w*)\)")]
        public void WhenHHitXs(string hitName, string intersectionsName)
        {
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];

            Intersection hit = intersections.GetHit();

            ScenarioContext.Current[hitName] = hit;
        }

        [When(@"(\w*) ← transform\((\w*), (\w*)\)")]
        public void WhenRTransformRM(string transformationName, string rayName, string matrixName)
        {
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            ScenarioContext.Current[transformationName] = ray.Transform(matrix);
        }

        [When(@"set_transform\((\w*), (\w*)\)")]
        public void WhenSet_TransformST(string shapeName, string matrixName)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            shape.Transform = matrix;
        }

        [When(@"set_transform\((\w*), scaling\((.*), (.*), (.*)\)\)")]
        public void WhenSet_TransformSScaling(string shapeName, double x, double y, double z)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            shape.Transform = Matrix.Scale(x, y, z);
        }


        [When(@"set_transform\((\w*), translation\((.*), (.*), (.*)\)\)")]
        public void WhenSet_TransformSTranslation(string shapeName, double x, double y, double z)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            shape.Transform = Matrix.Translation(x, y, z);
        }

        [When(@"(\w*) ← normal_at\((\w*), point\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)\)")]
        public void WhenNNormal_AtSPoint(string normalName, string shapeName, double x, double y, double z)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[normalName] = shape.NormalAt(new Point(x,y,z));
        }

        [When(@"(\w*) ← normal_at\((\w*), point\(√(\d*)\/(\d*), √(\d*)\/(\d*), √(\d*)\/(\d*)\)\)")]
        public void WhenNNormal_AtSPoint2(string normalName, string shapeName, double x1, double x2, double y1, double y2, double z1, double z2)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            var point = new Point(Math.Sqrt(x1) / x2, Math.Sqrt(y1) / y2, Math.Sqrt(z1) / z2);

            ScenarioContext.Current[normalName] = shape.NormalAt(point);
        }


        [When(@"(\w*) ← normal_at\((\w*), point\((\d*), √(\d*)\/(\d*), -√(\d*)\/(\d*)\)\)")]
        public void WhenNNormal_AtSPoint2(string normalName, string shapeName, double x, double y1, double y2, double z1, double z2)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            var point = new Point(x, Math.Sqrt(y1) / y2, -Math.Sqrt(z1) / z2);

            ScenarioContext.Current[normalName] = shape.NormalAt(point);
        }

        [When(@"(\w*) ← reflect\((\w*), (\w*)\)")]
        public void WhenRReflectVN(string reflectionName, string vectorName, string normalName)
        {
            var vector = (Vector)ScenarioContext.Current[vectorName];
            var normal = (Vector)ScenarioContext.Current[normalName];

            ScenarioContext.Current[reflectionName] = vector.Reflect(normal).AsVector();
        }

        [When(@"(\w*) ← point_light\((\w*), (\w*)\)")]
        public void WhenLightPoint_LightPositionIntensity(string lightName, string positionName, string colourName)
        {
            Point positon = (Point)ScenarioContext.Current[positionName];
            RColor colour = (RColor)ScenarioContext.Current[colourName];

            ScenarioContext.Current[lightName] = new PointLight(positon, colour);
        }

        [When(@"(\w*) ← (\w*)\.material")]
        public void WhenMS_Material(string matieralName, string shapeName)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[matieralName] = shape.Material;
        }

        [When(@"(\w*)\.material ← (\w*)")]
        public void WhenS_MaterialM(string shapeName, string materialName)
        {
            var shape = (Shape)ScenarioContext.Current[shapeName];
            var material = (Material)ScenarioContext.Current[materialName];

            shape.Material = material;
        }

        [When(@"(\w*) ← lighting\((\w*), (\w*), (\w*), (\w*), (\w*)\)")]
        public void WhenResultLightingMLightPositionEyevNormalv(string resultName, string materialName, string lightName, string postionName, string eyeName, string normalName)
        {
            var material = (Material)ScenarioContext.Current[materialName];
            var light = (PointLight)ScenarioContext.Current[lightName];
            var postion = (Point)ScenarioContext.Current[postionName];
            var eye = (Vector)ScenarioContext.Current[eyeName];
            var normal = (Vector)ScenarioContext.Current[normalName];


            ScenarioContext.Current[resultName] = material.Lighting(light,postion,eye,normal);
        }

        [When(@"(\w*) ← default_world\(\)")]
        public void DefaultWWorld(string worldName)
        {
            ScenarioContext.Current[worldName] = World.Default();
        }

        [When(@"(\w*) ← intersect_world\((\w*), (\w*)\)")]
        public void WhenXsIntersect_WorldWorldRay(string intersectionsName, string worldName, string rayName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            var intersections = world.Intersect(ray);
            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [When(@"prepare_hit\((\w*), (\w*)\)")]
        public void WhenPrepare_HitHitRay(string intersectionName, string rayName)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];

            intersection.PrepareHit(ray, new Intersections());
        }

        [When(@"(\w*) ← shade_hit\((\w*), (\w*)\)")]
        public void WhenCShade_HitWorldHit(string colorName, string worldName, string hitName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];

            RColor color = world.ShadeHit(hit);
            ScenarioContext.Current[colorName] = color;
        }

        [When(@"(\w*) ← color_at\((\w*), (\w*)\)")]
        public void WhenCColor_AtWorldRay(string colorName, string worldName, string rayName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            RColor color = world.ColorAt(ray);

            ScenarioContext.Current[colorName] = color;

        }

        [When(@"(\w*) ← view_transform\((\w*), (\w*), (\w*)\)")]
        public void WhenTView_TransformFromToUp(string transformName, string fromName, string toName, string upName)
        {
            Point from = (Point)ScenarioContext.Current[fromName];
            Point to = (Point)ScenarioContext.Current[toName];
            Vector up = (Vector)ScenarioContext.Current[upName];

            Matrix tranfrom = Matrix.ViewTransform(from, to, up);
            ScenarioContext.Current[transformName] = tranfrom;
        }

        [When(@"(\w*) ← camera\((\w*), (\w*), (\w*)\)")]
        public void WhenCCameraHsizeVsizeField_Of_View(string cameraName, string hName, string vName, string fovName)
        {

            var hSize = (double)ScenarioContext.Current[hName];
            var vSize = (double)ScenarioContext.Current[vName];
            var fieldOfView = (double)ScenarioContext.Current[fovName];
            ScenarioContext.Current[cameraName] = new Camera(hSize, vSize, fieldOfView);
        }

        [When(@"(\w*) ← ray_for_pixel\((\w*), (.*), (.*)\)")]
        public void WhenRRay_For_PixelC(string rayName, string cameraName, double x, double y)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            ScenarioContext.Current[rayName] = camera.RayForPixel(x,y);
        }

        [When(@"(\w*)\.transform ← rotation_y\(π/(.*)\) \* translation\((.*), (.*), (.*)\)")]
        public void WhenC_TransformRotation_YΠTranslation(string cameraName, double degree, double x, double y, double z)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            camera.Transform = Matrix.RotateY(Math.PI / degree) * Matrix.Translation(x, y, z);
        }

        [When(@"(\w*) ← render\((\w*), (\w*)\)")]
        public void WhenImageRenderCW(string imageName, string cameraName, string worldName)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            World world = (World)ScenarioContext.Current[worldName];
            ScenarioContext.Current[imageName] = camera.Render(world);
        }

        /***** Shadows ****/

        [When(@"(\w*) ← lighting\((\w*), (\w*), (\w*), (\w*), (\w*), (\w*)\)")]
        public void WhenResultLightingMLightPositionEyevNormalvIn_Shadow(string resultName, string materialName, string lightName, string positionName, string eyeName, string normalName, string inshadowName)
        {
            Material material = (Material)ScenarioContext.Current[materialName];
            Light light = (Light)ScenarioContext.Current[lightName];
            Point position = (Point)ScenarioContext.Current[positionName];
            Vector eye = (Vector)ScenarioContext.Current[eyeName];
            Vector normal = (Vector)ScenarioContext.Current[normalName];
            bool inShadow = (bool)ScenarioContext.Current[inshadowName]; 

            ScenarioContext.Current[resultName] = material.Lighting(light, position, eye, normal, inShadow);
        }

        /***** Plains ****/

        [When(@"(\w*) ← local_normal_at\((\w*), point\((.*), (.*), (.*)\)\)")]
        public void WhenNLocal_Normal_AtPPoint(string resultName, string planeName, double x, double y, double z)
        {
            Plane plane = (Plane)ScenarioContext.Current[planeName];
            Point point = new Point(x, y, z);
            Vector result = plane.LocalNormalAt(point).AsVector();
            ScenarioContext.Current[resultName] = result;
        }

        [When(@"(\w*) ← local_intersect\((\w*), (\w*)\)")]
        public void WhenXsLocal_IntersectPR(string resultName, string planeName, string rayName)
        {
            Plane plane = (Plane)ScenarioContext.Current[planeName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Intersections result = plane.LocalIntersect(ray);
            ScenarioContext.Current[resultName] = result;
        }


        /***** Patterns ****/

        [When(@"(\w*) ← lighting\((\w*), (\w*), point\((.*), (.*), (.*)\), (\w*), (\w*), (\w*)\)")]
        public void WhenCLightingMLightPointEyevNormalvFalse(string resultName, string materialName, string lightName, double x, double y, double z, string eyeName, string normalName, string inshadowName)
        {
            Material material = (Material)ScenarioContext.Current[materialName];
            Light light = (Light)ScenarioContext.Current[lightName];
            Point position = new Point(x,y,z);
            Vector eye = (Vector)ScenarioContext.Current[eyeName];
            Vector normal = (Vector)ScenarioContext.Current[normalName];
            bool inShadow = Convert.ToBoolean(inshadowName);


            ScenarioContext.Current[resultName] = material.Lighting(light, position, eye, normal);
        }

        [When(@"(\w*) ← stripe_at_object\((\w*), (\w*), point\((.*), (.*), (.*)\)\)")]
        public void WhenCStripe_At_ObjectPatternObjectPoint(string resultName, string patternName, string shapeName, double x, double y, double z)
        {
            Pattern pattern = (Pattern)ScenarioContext.Current[patternName];
            Shape shape = (Shape)ScenarioContext.Current[shapeName];
            Point point = new Point(x, y, z);

            ScenarioContext.Current[resultName] = pattern.ColorAt(shape, point);
        }

        [When(@"set_pattern_transform\((\w*), translation\((.*), (.*), (.*)\)\)")]
        public void WhenSet_Pattern_TransformPatternTranslation(string patternName, double x, double y, double z)
        {
            Pattern pattern = (Pattern)ScenarioContext.Current[patternName];
            pattern.Transform = Matrix.Translation(x, y, z);
        }

        [When(@"(\w*) ← pattern_at_shape\((\w*), (\w*), point\((.*), (.*), (.*)\)\)")]
        public void WhenCPattern_At_ShapePatternShapePoint(string colorName, string patternName, string shapeName,  double x, double y, double z)
        {
            Pattern pattern = (Pattern)ScenarioContext.Current[patternName];
            Shape shape = (Shape)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[colorName] = pattern.ColorAt(shape, new Point(x, y, z));
        }

        /***** Reflection ****/

        [When(@"(\w*) ← reflected_color\((\w*), (\w*)\)")]
        public void WhenColorReflected_ColorWorldHit(string colorName, string worldName, string hitName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];

            ScenarioContext.Current[colorName] = world.ReflectedColor(hit, 5);
            //ScenarioContext.Current.Pending();
        }

        [When(@"(\w*) ← reflected_color\((\w*), (\w*), (.*)\)")]
        public void WhenColorReflected_ColorWorldHit(string colorName, string worldName, string hitName, int limit)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];
            ScenarioContext.Current[colorName] = world.ReflectedColor(hit, limit);
        }

        [When(@"prepare_hit\((\w*), (\w*), (\w*)\)")]
        public void WhenPrepare_HitHitRayXs(string hitName, string rayName, string intersectionsName)
        {
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];
            hit.PrepareHit(ray, intersections);
        }

        [When(@"prepare_hit\((\w*)\[(.*)], (\w*), xs\)")]
        public void WhenPrepare_HitXsRayXs(string intersectionsName, int position, string rayName)
        {
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];
            Intersection intersection = intersections[position];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            intersection.PrepareHit(ray, intersections);
        }

        [When(@"(\w*) ← refracted_color\((\w*), (\w*)\[(.*)], (.*)\)")]
        public void WhenCRefracted_ColorWorldXs(string colorName, string worldName, string intersectionsName, int position, int remaining)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];

            Intersection hit = intersections[position];

            RColor color = world.RefractedColor(hit, remaining);
            ScenarioContext.Current[colorName] = color;
        }

        [When(@"(\w*) ← schlick\((\w*)\[(\d*)]\)")]
        public void WhenReflectanceSchlickXs(string reflectanceName, string intersectionsName, int position)
        {
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];
            Intersection hit = intersections[position];
            ScenarioContext.Current[reflectanceName] = hit.Schlick();
        }

        [When(@"(\w*) ← shade_hit\((\w*), (\w*)\[(.*)]\)")]
        public void WhenColorShade_HitWorldXs(string colorName, string worldName, string intersectionsName, int position)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];
            Intersection hit = intersections[position];

            RColor color = world.ShadeHit(hit, 1);
            ScenarioContext.Current[colorName] = color;
        }

        [When(@"prepare_computations\((\w*), (\w*)\)")]
        public void WhenPrepare_ComputationsHitRay(string hitName, string rayName)
        {
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];

            hit.PrepareComputations(ray);
            //ScenarioContext.Current.Pending();
        }

    }
}
