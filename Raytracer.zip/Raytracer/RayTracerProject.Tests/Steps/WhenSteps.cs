﻿using System;
using TechTalk.SpecFlow;

namespace RayTracerProject.Tests
{
    [Binding]
    public class WhenSteps
    {
        [When(@"(\w*) ← ray\((\w*), (\w*)\)")]
        public void WhenRRayOriginDirection(string rayName, string pointName,string vectorName )
        {
            var point = (Point)ScenarioContext.Current[pointName];
            var vector = (Vector)ScenarioContext.Current[vectorName];

            ScenarioContext.Current[rayName] = new Ray(point, vector);
        }


        [When(@"(\w*) ← intersect\((\w*), (\w*)\)")]
        public void WhenXsIntersectSR(string intersectionName, string sphereName, string rayName)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var ray = (Ray)ScenarioContext.Current[rayName];


            ScenarioContext.Current[intersectionName] = ray.Intersect(sphere);
        }

        [When(@"(\w*) ← intersection\((.*), (\w*)\)")]
        public void WhenIIntersectionS(string intersectionName, double time, string shapeName)
        {
            var sphere = (Sphere)ScenarioContext.Current[shapeName];

            ScenarioContext.Current[intersectionName] = new Intersection(time, sphere);
        }
        [When(@"(\w*) ← intersections\((\w*), (\w*)\)")]
        public void WhenXsIntersectionsII(string intersectionsName, string intersection1Name, string intersection2Name)
        {
            Intersection intersection1 = (Intersection)ScenarioContext.Current[intersection1Name];
            Intersection intersection2 = (Intersection)ScenarioContext.Current[intersection2Name];

            Intersections intersections = new Intersections();
            intersections.Add(intersection1);
            intersections.Add(intersection2);

            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [When(@"(\w*) ← hit\((\w*)\)")]
        public void WhenHHitXs(string hitName, string intersectionsName)
        {
            Intersections intersections = (Intersections)ScenarioContext.Current[intersectionsName];

            Intersection hit = intersections.GetHit();

            ScenarioContext.Current[hitName] = hit;
        }

        [When(@"(\w*) ← transform\((\w*), (\w*)\)")]
        public void WhenRTransformRM(string transformationName, string rayName, string matrixName)
        {
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];
            ScenarioContext.Current[transformationName] = ray.Transform(matrix);
        }

        [When(@"set_transform\((\w*), (\w*)\)")]
        public void WhenSet_TransformST(string sphereName, string matrixName)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            Matrix matrix = (Matrix)ScenarioContext.Current[matrixName];

            sphere.Transform = matrix;
        }

        [When(@"set_transform\((\w*), scaling\((.*), (.*), (.*)\)\)")]
        public void WhenSet_TransformSScaling(string sphereName, double x, double y, double z)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            sphere.Transform = Matrix.Scale(x, y, z);
        }


        [When(@"set_transform\((\w*), translation\((.*), (.*), (.*)\)\)")]
        public void WhenSet_TransformSTranslation(string sphereName, double x, double y, double z)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            sphere.Transform = Matrix.Translation(x, y, z);
        }

        [When(@"(\w*) ← normal_at\((\w*), point\((-?\d*\.?\d*), (-?\d*\.?\d*), (-?\d*\.?\d*)\)\)")]
        public void WhenNNormal_AtSPoint(string normalName, string sphereName, double x, double y, double z)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];

            ScenarioContext.Current[normalName] = sphere.NormalAt(new Point(x,y,z));
        }

        [When(@"(\w*) ← normal_at\((\w*), point\(√(\d*)\/(\d*), √(\d*)\/(\d*), √(\d*)\/(\d*)\)\)")]
        public void WhenNNormal_AtSPoint2(string normalName, string sphereName, double x1, double x2, double y1, double y2, double z1, double z2)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var point = new Point(Math.Sqrt(x1) / x2, Math.Sqrt(y1) / y2, Math.Sqrt(z1) / z2);

            ScenarioContext.Current[normalName] = sphere.NormalAt(point);
        }


        [When(@"(\w*) ← normal_at\((\w*), point\((\d*), √(\d*)\/(\d*), -√(\d*)\/(\d*)\)\)")]
        public void WhenNNormal_AtSPoint2(string normalName, string sphereName, double x, double y1, double y2, double z1, double z2)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var point = new Point(x, Math.Sqrt(y1) / y2, -Math.Sqrt(z1) / z2);

            ScenarioContext.Current[normalName] = sphere.NormalAt(point);
        }

        [When(@"(\w*) ← reflect\((\w*), (\w*)\)")]
        public void WhenRReflectVN(string reflectionName, string vectorName, string normalName)
        {
            var vector = (Vector)ScenarioContext.Current[vectorName];
            var normal = (Vector)ScenarioContext.Current[normalName];

            ScenarioContext.Current[reflectionName] = vector.Reflect(normal).AsVector();
        }

        [When(@"(\w*) ← point_light\((\w*), (\w*)\)")]
        public void WhenLightPoint_LightPositionIntensity(string lightName, string positionName, string colourName)
        {
            Point positon = (Point)ScenarioContext.Current[positionName];
            RColor colour = (RColor)ScenarioContext.Current[colourName];

            ScenarioContext.Current[lightName] = new PointLight(positon, colour);
        }

        [When(@"(\w*) ← (\w*)\.material")]
        public void WhenMS_Material(string matieralName, string sphereName)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];

            ScenarioContext.Current[matieralName] = sphere.Material;
        }

        [When(@"(\w*)\.material ← (\w*)")]
        public void WhenS_MaterialM(string sphereName, string materialName)
        {
            var sphere = (Sphere)ScenarioContext.Current[sphereName];
            var material = (Material)ScenarioContext.Current[materialName];

            sphere.Material = material;
        }

        [When(@"(\w*) ← lighting\((\w*), (\w*), (\w*), (\w*), (\w*)\)")]
        public void WhenResultLightingMLightPositionEyevNormalv(string resultName, string materialName, string lightName, string postionName, string eyeName, string normalName)
        {
            var material = (Material)ScenarioContext.Current[materialName];
            var light = (PointLight)ScenarioContext.Current[lightName];
            var postion = (Point)ScenarioContext.Current[postionName];
            var eye = (Vector)ScenarioContext.Current[eyeName];
            var normal = (Vector)ScenarioContext.Current[normalName];

            ScenarioContext.Current[resultName] = material.Lighting(light,postion,eye,normal);
        }

        [When(@"(\w*) ← default_world\(\)")]
        public void DefaultWWorld(string worldName)
        {
            ScenarioContext.Current[worldName] = World.Default();
        }

        [When(@"(\w*) ← intersect_world\((\w*), (\w*)\)")]
        public void WhenXsIntersect_WorldWorldRay(string intersectionsName, string worldName, string rayName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            var intersections = world.Intersect(ray);
            ScenarioContext.Current[intersectionsName] = intersections;
        }

        [When(@"prepare_hit\((\w*), (\w*)\)")]
        public void WhenPrepare_HitHitRay(string intersectionName, string rayName)
        {
            Intersection intersection = (Intersection)ScenarioContext.Current[intersectionName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];

            intersection.PerpareHit(ray);
        }

        [When(@"(\w*) ← shade_hit\((\w*), (\w*)\)")]
        public void WhenCShade_HitWorldHit(string colorName, string worldName, string hitName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Intersection hit = (Intersection)ScenarioContext.Current[hitName];

            RColor color = world.ShadeHit(hit);
            ScenarioContext.Current[colorName] = color;
        }

        [When(@"(\w*) ← color_at\((\w*), (\w*)\)")]
        public void WhenCColor_AtWorldRay(string colorName, string worldName, string rayName)
        {
            World world = (World)ScenarioContext.Current[worldName];
            Ray ray = (Ray)ScenarioContext.Current[rayName];
            RColor color = world.ColorAt(ray);

            ScenarioContext.Current[colorName] = color;

        }

        [When(@"(\w*) ← view_transform\((\w*), (\w*), (\w*)\)")]
        public void WhenTView_TransformFromToUp(string transformName, string fromName, string toName, string upName)
        {
            Point from = (Point)ScenarioContext.Current[fromName];
            Point to = (Point)ScenarioContext.Current[toName];
            Vector up = (Vector)ScenarioContext.Current[upName];

            Matrix tranfrom = Matrix.ViewTransform(from, to, up);
            ScenarioContext.Current[transformName] = tranfrom;
        }

        [When(@"(\w*) ← camera\((\w*), (\w*), (\w*)\)")]
        public void WhenCCameraHsizeVsizeField_Of_View(string cameraName, string hName, string vName, string fovName)
        {

            var hSize = (double)ScenarioContext.Current[hName];
            var vSize = (double)ScenarioContext.Current[vName];
            var fieldOfView = (double)ScenarioContext.Current[fovName];
            ScenarioContext.Current[cameraName] = new Camera(hSize, vSize, fieldOfView);
        }

        [When(@"(\w*) ← ray_for_pixel\((\w*), (.*), (.*)\)")]
        public void WhenRRay_For_PixelC(string rayName, string cameraName, double x, double y)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            ScenarioContext.Current[rayName] = camera.RayForPixel(x,y);
        }

        [When(@"(\w*)\.transform ← rotation_y\(π/(.*)\) \* translation\((.*), (.*), (.*)\)")]
        public void WhenC_TransformRotation_YΠTranslation(string cameraName, double degree, double x, double y, double z)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            camera.Transform = Matrix.RotateY(Math.PI / degree) * Matrix.Translation(x, y, z);
        }

        [When(@"(\w*) ← render\((\w*), (\w*)\)")]
        public void WhenImageRenderCW(string imageName, string cameraName, string worldName)
        {
            Camera camera = (Camera)ScenarioContext.Current[cameraName];
            World world = (World)ScenarioContext.Current[worldName];
            ScenarioContext.Current[imageName] = camera.Render(world);
        }



    }
}
